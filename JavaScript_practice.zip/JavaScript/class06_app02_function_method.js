<!Doctype>
<html>
<head>

<title>Java Script</title>
<script>
function displayFunction(){
alert("hii every one welcome to java script programming");
}
</script>
</head>
<body>
<Button onload="displayFunction()">click here</Button>
<h2>Hello Users</h2>

</body>