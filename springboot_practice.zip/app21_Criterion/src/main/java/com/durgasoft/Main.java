package com.durgasoft;

import com.durgasoft.entities.Employee;
import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.boot.registry.StandardServiceRegistryBuilder;
import org.hibernate.cfg.Configuration;
import org.hibernate.criterion.*;
import java.util.List;



public class Main {
    public static void main(String[] args) {
        Configuration configuration = new Configuration();
        configuration.configure();
        SessionFactory sessionFactory = configuration.buildSessionFactory(
                new StandardServiceRegistryBuilder().applySettings(configuration.getProperties()).build());
        Session session = sessionFactory.openSession();
        Criteria criteria = session.createCriteria(Employee.class);
        Criterion criterion1 = Restrictions.ge("esal", 6000);
        Criterion criterion2 = Restrictions.le("esal", 9000);
        criteria.add(criterion1);
        criteria.add(criterion2);
        ProjectionList projectionList = Projections.projectionList();
        projectionList.add(Projections.property("eno"));
        projectionList.add(Projections.property("ename"));
        projectionList.add(Projections.property("esal"));
        projectionList.add(Projections.property("eaddr"));
        criteria.setProjection(projectionList);
        Order order = Order.desc("ename");
        criteria.addOrder(order);
        List<Object[]> list = criteria.list();
        for (Object[] objs: list){
            for (Object obj: objs){
                System.out.print(obj+"\t");
            }
            System.out.println();
        }
        session.close();
        sessionFactory.close();

    }
}