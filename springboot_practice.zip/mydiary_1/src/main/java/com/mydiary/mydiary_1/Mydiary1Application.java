package com.mydiary.mydiary_1;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Mydiary1Application {

    public static void main(String[] args) {
        SpringApplication.run(Mydiary1Application.class, args);
    }

}
