package com.durgasoft.beans;

import javax.persistence.*;

@Entity
@Table(name = "emp5")
public class Employee {
    @Id
    @Column(name = "eno")
    private int eno;
    @Column(name = "ename")
    private String ename;
    @Column(name = "esal")
    private float esal;
    @Embedded
    private Account account;
    @Embedded
    private Address address;

    public int getEno() {
        return eno;
    }

    public void setEno(int eno) {
        this.eno = eno;
    }

    public String getEname() {
        return ename;
    }

    public void setEname(String ename) {
        this.ename = ename;
    }

    public float getEsal() {
        return esal;
    }

    public void setEsal(float esal) {
        this.esal = esal;
    }

    public Account getAccount() {
        return account;
    }

    public void setAccount(Account account) {
        this.account = account;
    }

    public Address getAddress() {
        return address;
    }

    public void setAddress(Address address) {
        this.address = address;
    }
}
