package com.durgasoft.beans;

import javax.persistence.Column;
import javax.persistence.Embeddable;
import javax.persistence.Entity;

@Entity
@Embeddable
public class  Account {
    @Column(name = "accountNo")
    private int accountNo;
    @Column(name = "accountHolderName")
    private String accountHolderName;
    @Column(name = "accountType")
    private String accountType;

    public int getAccountNo() {

        return accountNo;
    }

    public void setAccountNo(int accountNo) {
        this.accountNo = accountNo;
    }

    public String getAccountHolderName() {
        return accountHolderName;
    }

    public void setAccountHolderName(String accountHolderName) {
        this.accountHolderName = accountHolderName;
    }

    public String getAccountType() {
        return accountType;
    }

    public void setAccountType(String accountType) {
        this.accountType = accountType;
    }
}
