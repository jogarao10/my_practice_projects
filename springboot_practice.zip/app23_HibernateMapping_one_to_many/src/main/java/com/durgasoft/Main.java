package com.durgasoft;

import com.durgasoft.beans.Account;
import com.durgasoft.beans.Address;
import com.durgasoft.beans.Employee;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.boot.registry.StandardServiceRegistryBuilder;
import org.hibernate.cfg.Configuration;
import org.hibernate.Transaction;


public class Main {
    public static void main(String[] args) {
        Configuration configuration = new Configuration();
        configuration.configure();

        SessionFactory sessionFactory = configuration.buildSessionFactory(
                new StandardServiceRegistryBuilder().applySettings(configuration.getProperties()).build()
        );

        Session session = sessionFactory.openSession();

        Account account = new Account();
        account.setAccountNo(1775);
        account.setAccountHolderName("Jai");
        account.setAccountType("Savings");

        Address address = new Address();
        address.setHno("3-307");
        address.setCity("Kaviti");
        address.setPin(5322);

        Employee employee = new Employee();
        employee.setEno(444);
        employee.setEname("Jai");
        employee.setEsal(10000);
        employee.setAccount(account);
        employee.setAddress(address);

        Transaction transaction = session.beginTransaction();
        session.save(employee);
        transaction.commit();
        System.out.println("Employee Inserted Successfully");
        session.close();
        sessionFactory.close();


    }
}