package com.diary.mydiary;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MydiaryApplicationTests {

    @Test
    void contextLoads() {
    }

}
