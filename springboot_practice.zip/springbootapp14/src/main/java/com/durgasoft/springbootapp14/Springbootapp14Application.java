package com.durgasoft.springbootapp14;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Springbootapp14Application {

    public static void main(String[] args) {
        SpringApplication.run(Springbootapp14Application.class, args);
    }

}
