package com.durgasoft.springbootapp14.Controller;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class AppController {
    @Value("${message}")
    public String message;
    @RequestMapping("/app")
    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {

        this.message = message;
    }
}
