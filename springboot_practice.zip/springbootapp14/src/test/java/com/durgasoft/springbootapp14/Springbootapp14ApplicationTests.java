package com.durgasoft.springbootapp14;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Springbootapp14ApplicationTests {

    @Test
    void contextLoads() {
    }

}
