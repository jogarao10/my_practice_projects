package com.durgasoft.springbootapp13;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Springbootapp13ApplicationTests {

    @Test
    void contextLoads() {
    }

}
