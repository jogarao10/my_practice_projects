package com.durgasoft.springbootapp13.Controller;

import com.durgasoft.springbootapp13.Beans.CustomerBean;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;


@RestController
public class CustomerController {
    @Autowired
    private CustomerBean customerBean;
    @RequestMapping("cust")
    public String getCustomerDetails(){
        String data = "<h1>Customer Details        :  <br>" ;
        data = data + customerBean.getCid()+", ";
        data = data + customerBean.getCname()+", ";
        data = data + customerBean.getCmail()+", ";
        data = data + customerBean.getCaddr()+"<h1>";
        return data;
    }

}
