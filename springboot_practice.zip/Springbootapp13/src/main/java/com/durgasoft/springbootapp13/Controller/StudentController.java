package com.durgasoft.springbootapp13.Controller;

import com.durgasoft.springbootapp13.Beans.StudentBean;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class StudentController {
    @Autowired
    private StudentBean studentBean;
    @RequestMapping("/std")
    public String getStudentDetails(){
        String data = "<h1> Student Details  :  <br> Student Number  : ";
        data = data + studentBean.getSno()+"<br>";
        data = data + studentBean.getSid()+", ";
        data = data + studentBean.getSname()+", ";
        data = data + studentBean.getSmail()+", ";
        data = data + studentBean.getEmobile()+"</h1> ";
        return data;
    }
}
