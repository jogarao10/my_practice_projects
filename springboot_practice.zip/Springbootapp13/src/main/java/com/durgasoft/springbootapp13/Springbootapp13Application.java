package com.durgasoft.springbootapp13;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Springbootapp13Application {

    public static void main(String[] args) {

        SpringApplication.run(Springbootapp13Application.class, args);
    }

}
