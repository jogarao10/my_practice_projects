package com.durgasoft.springbootapp24_in_memory_databases;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Springbootapp24InMemoryDatabasesApplication {

    public static void main(String[] args) {
        SpringApplication.run(Springbootapp24InMemoryDatabasesApplication.class, args);
    }

}
