package com.durgasoft.springbootapp24_in_memory_databases.employeeRepository;

import com.durgasoft.springbootapp24_in_memory_databases.beans.Employee;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface EmployeeRepository extends JpaRepository<Employee,Integer> {
}
