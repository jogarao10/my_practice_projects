package com.durgasoft.springbootapp24_in_memory_databases;

import com.durgasoft.springbootapp24_in_memory_databases.beans.Employee;
import com.durgasoft.springbootapp24_in_memory_databases.employeeRepository.EmployeeRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.ApplicationArguments;
import org.springframework.boot.ApplicationRunner;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

@Component
public class EmployeeRunner implements ApplicationRunner {
    @Autowired
    private EmployeeRepository employeeRepository;
    @Transactional
    @Override
    public void run(ApplicationArguments args) throws Exception {
        Employee employee = new Employee();
        employee.setEname("Chanti");
        employee.setEsal(5000);
        employee.setEaddr("Hyd");
        Employee emp = employeeRepository.save(employee);
//        System.out.println(emp);

        Employee emp1 = employeeRepository.findById(1).get();
        System.out.println(emp1);

        emp1.setEname("Susanth");
        emp1.setEsal(7000);
        emp1.setEaddr("Pune");
        Employee employee1 = employeeRepository.findById(1).get();
        System.out.println(employee1);

        employeeRepository.deleteById(1);



    }
}
