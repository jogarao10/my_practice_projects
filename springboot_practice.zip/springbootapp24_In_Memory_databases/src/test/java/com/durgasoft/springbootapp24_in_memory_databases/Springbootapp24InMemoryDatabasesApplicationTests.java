package com.durgasoft.springbootapp24_in_memory_databases;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Springbootapp24InMemoryDatabasesApplicationTests {

    @Test
    void contextLoads() {
    }

}
