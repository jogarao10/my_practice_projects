package com.durgasoft.springbootapp22_spring_data_jpa;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Springbootapp22SpringDataJpaApplicationTests {

    @Test
    void contextLoads() {
    }

}
