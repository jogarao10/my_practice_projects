package com.durgasoft.springbootapp22_spring_data_jpa;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@SpringBootApplication

public class Springbootapp22SpringDataJpaApplication {

        public static void main(String[] args) {
            SpringApplication.run(Springbootapp22SpringDataJpaApplication.class, args);
         }

}
