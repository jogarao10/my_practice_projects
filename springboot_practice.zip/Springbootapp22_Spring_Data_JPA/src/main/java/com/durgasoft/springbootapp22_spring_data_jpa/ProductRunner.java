package com.durgasoft.springbootapp22_spring_data_jpa;

import com.durgasoft.springbootapp22_spring_data_jpa.Controller.ProductController;
import com.durgasoft.springbootapp22_spring_data_jpa.beans.Product;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.ApplicationArguments;
import org.springframework.boot.ApplicationRunner;
import org.springframework.stereotype.Component;
import org.springframework.web.bind.annotation.RequestMapping;

import java.util.Scanner;

@Component
public class ProductRunner implements ApplicationRunner {
    @Autowired
    private ProductController productController;

    @Override
    public void run(ApplicationArguments args) throws Exception {

        Product product = new Product();
        System.out.println("Enter your Required Product :  ");
        Scanner scanner = new Scanner(System.in);
        String pname = scanner.next();
        product.setPname(pname);
        System.out.println("Enter your Effortable prize :  ");
        int pcost = scanner.nextInt();
        product.setPcost(pcost);
        Product prd = productController.addProduct(product);
        System.out.println(prd);

         
        /*System.out.print("Enter product Id  : ");
        Scanner scanner = new Scanner(System.in);
        int productId = scanner.nextInt();
        Product product = productController.getProductByPID(productId);
        System.out.println(product);

         */
        /*System.out.print("Enter Product Name  :  ");
        Scanner scanner = new Scanner(System.in);
        String productName = scanner.next();
        Product product = productController.getProductByPname(productName);
        System.out.println(product);
        */

        /*Product product = new Product();
        System.out.print("which product we want to change please enter product Id   : ");
        Scanner scanner = new Scanner(System.in);
        int productId = scanner.nextInt();
        product.setPid(productId);

        System.out.print("Please enter your changing product Name : ");
        String productName = scanner.next();
        product.setPname(productName);


        System.out.print("Please enter your latest product Cost");
        int productCost = scanner.nextInt();
        product.setPcost(productCost);
        Product prd = productController.update(product);
        System.out.println(prd);

        System.out.println("Product details Updated Successfully ");

         */
        /*System.out.print("which product we want to delete please enter product Id Number : ");
        Scanner scanner = new Scanner(System.in);
        int productId = scanner.nextInt();
        String status = productController.delete(productId);
        System.out.println(status);

         */



    }
}
