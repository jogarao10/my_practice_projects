package com.durgasoft.springbootapp22_spring_data_jpa.Service;

import com.durgasoft.springbootapp22_spring_data_jpa.Repository.ProductRepository;
import com.durgasoft.springbootapp22_spring_data_jpa.beans.Product;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.RestController;

import java.util.Scanner;

@Service
public class ProductServiceImpl implements ProductService{
    @Autowired
    private ProductRepository productRepository;
    @Transactional
    @Override
    public Product addProduct(Product product) {
        Product prd = productRepository.save(product);
        return prd;
    }

    @Override
    public Product getProductByPID(int pid) {

        Product product = productRepository.findById(pid).get();

        return product;
    }

    @Override
    public Product getProductByPname(String pname) {
        Product product = productRepository.findProductByPname(pname);
        return product;
    }

    @Transactional
    @Override
    public Product update(Product product) {
        Product prd = productRepository.findById(product.getPid()).get();
        prd.setPname(product.getPname());
        prd.setPcost(product.getPcost());
        return prd;
    }

    @Override
    public String delete(int pid) {
        productRepository.deleteById(pid);
        return "SUCCESSFULLY DELETED";
    }
}
