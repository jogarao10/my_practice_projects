package com.durgasoft.springbootapp22_spring_data_jpa.Service;

import com.durgasoft.springbootapp22_spring_data_jpa.beans.Product;

public interface ProductService {
    public Product addProduct(Product product);
    public Product getProductByPID(int pid);
    public Product getProductByPname(String pname);
    public Product update(Product product);
    public String delete(int pid);
}
