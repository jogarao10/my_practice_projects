package com.durgasoft.springbootapp22_spring_data_jpa.Controller;

import com.durgasoft.springbootapp22_spring_data_jpa.Service.ProductService;
import com.durgasoft.springbootapp22_spring_data_jpa.beans.Product;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;


@Controller
@RestController
public class ProductController {
    @Autowired
    private ProductService productService;
    @RequestMapping("/product")
    public Product addProduct(Product product){
        Product prd = productService.addProduct(product);
        return prd;
    }
    public Product getProductByPID(int pid){
        Product product = productService.getProductByPID(pid);
        return product;
    }
    public Product getProductByPname(String pname){
        Product product = productService.getProductByPname(pname);
        return product;
    }
    public Product update(Product product){
        Product prd = productService.update(product);
        return prd;
    }
    public String delete(int pid){
        String status = productService.delete(pid);
        return status;
    }
}
