package com.durgasoft.springbootapp22_spring_data_jpa.Repository;
import com.durgasoft.springbootapp22_spring_data_jpa.beans.Product;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ProductRepository extends JpaRepository<Product, Integer> {
    public Product findProductByPname(String pname);
    public Product findProductByPcost(int pcost);
}
