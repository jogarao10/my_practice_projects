package com.example.springbootapp28_thymeleaf_css;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Springbootapp28ThymeleafCssApplicationTests {

    @Test
    void contextLoads() {
    }

}
