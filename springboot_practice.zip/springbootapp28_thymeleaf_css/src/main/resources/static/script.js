function validationForm() {
    let sid = document.forms["regForm"]["sid"].value;
    let sname = document.forms["regForm"]["sname"].value;
    let smail = document.forms["regForm"]["smail"].value;
    let sphone = document.forms["regForm"]["sphone"].value;
    let saddr = document.forms["regForm"]["saddr"].value;

    if (sid=="") {
        alert("Student Id is required");
        return false;
    }
    if (sname=="") {
        alert("Student Name is required");
        return false;
    }
    if (smail=="") {
        alert("Student Mail is required");
        return false;
    }
    if (sphone=="") {
        alert("Student Phone is required");
        return false;
    }
    if (saddr=="") {
        alert("Student Address is required");
        return false;
    }
}