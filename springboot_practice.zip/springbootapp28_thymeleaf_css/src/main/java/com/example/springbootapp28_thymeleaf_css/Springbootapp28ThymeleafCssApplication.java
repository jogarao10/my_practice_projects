package com.example.springbootapp28_thymeleaf_css;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Springbootapp28ThymeleafCssApplication {

    public static void main(String[] args) {
        SpringApplication.run(Springbootapp28ThymeleafCssApplication.class, args);
    }

}
