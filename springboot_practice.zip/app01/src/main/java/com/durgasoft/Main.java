package com.durgasoft;

import java.util.Collection;
@Spring
public class Main {
    public static void main(String[] args) {



    }
}