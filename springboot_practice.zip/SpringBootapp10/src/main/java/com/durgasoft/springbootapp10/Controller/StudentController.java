package com.durgasoft.springbootapp10.Controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class StudentController {
    @Autowired
    private Environment environment;
    @RequestMapping("/std")
    public String getStudentDetails(){
        String data = "<HTML> <h1> STUDENT DETAILS : ";
        data = data + environment.getProperty("student.sid")+", ";
        data = data + environment.getProperty("student.sname")+", ";
        data = data + environment.getProperty("student.saddr")+"<h1> <HTML>";

        return data;
    }
}
