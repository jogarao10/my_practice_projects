package com.durgasoft.springbootapp10;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringBootapp10Application {

    public static void main(String[] args) {

        SpringApplication.run(SpringBootapp10Application.class, args);
    }

}
