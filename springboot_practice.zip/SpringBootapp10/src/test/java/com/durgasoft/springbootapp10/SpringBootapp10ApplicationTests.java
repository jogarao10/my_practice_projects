package com.durgasoft.springbootapp10;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringBootapp10ApplicationTests {

    @Test
    void contextLoads() {
    }

}
