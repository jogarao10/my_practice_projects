package com.durgasoft.springbootapp15;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Springbootapp15ApplicationTests {

    @Test
    void contextLoads() {
    }

}
