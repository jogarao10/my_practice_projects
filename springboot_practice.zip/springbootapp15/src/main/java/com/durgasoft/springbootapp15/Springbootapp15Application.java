package com.durgasoft.springbootapp15;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Springbootapp15Application {

    public static void main(String[] args) {


        SpringApplication.run(Springbootapp15Application.class, args);

    }

}
