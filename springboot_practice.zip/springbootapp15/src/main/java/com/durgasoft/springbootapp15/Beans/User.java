package com.durgasoft.springbootapp15.Beans;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Component;

import java.util.List;
@ConfigurationProperties(prefix = "user")
@Component
public class User {
//    @Value("${user.uid}")
    private int uid;
//    @Value("${user.uname}")
    private String uname;
//    @Value("${user.uqal}")
    private String[] uqual;
//    @Value("${user.utech}")
    private List<String> utech;

    public List<String> getUtech() {
        return utech;
    }

    public void setUtech(List<String> utech) {
        this.utech = utech;
    }

    public int getUid() {
        return uid;
    }

    public void setUid(int uid) {
        this.uid = uid;
    }

    public String getUname() {
        return uname;
    }

    public void setUname(String uname) {
        this.uname = uname;
    }

    public String[] getUqual() {
        return uqual;
    }

    public void setUqual(String[] uqual) {
        this.uqual = uqual;
    }
}
