package com.durgasoft.springbootapp15.Controller;

import com.durgasoft.springbootapp15.Beans.User;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class userController {
    @Autowired
    private User user;
    @RequestMapping("user1")
    public String getUserDetails(){
        String data = "<h1>User Details  : \n";
        data = data+"User Id    :  "+user.getUid()+"\n";
        data = data+"User name  :  "+user.getUname()+"\n";

        data = data+"User Qualifications : ";
        for (String uqal: user.getUqual()){
            data = data + uqal;
        }
        data = data+"User Technologies : "+user.getUtech();
        data = data+"</h1>";
        System.out.println(user.getUqual().length);
        System.out.println(user.getUtech().size());

        return data;
    }
}
