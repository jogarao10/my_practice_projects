package com.example.springbootapp25_mongodb;

import com.example.springbootapp25_mongodb.beans.Product;
import com.example.springbootapp25_mongodb.repository.ProductRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import java.util.Arrays;
import java.util.List;

@Transactional
@Component
public class ProductRunner implements CommandLineRunner {

    @Autowired

    private ProductRepository productRepository;
    @Override
    public void run(String... args) throws Exception {
       /* Product product = new Product();

        product.setPid(111);
        product.setPname("Laptop");
        product.setPcost(50000);
        Product prd = productRepository.save(product);
        System.out.println(prd);*/

        /*List<Product> productList = Arrays.asList(new Product(222,"Mobile",25000),
                                                  new Product(333,"Keyboard",800),
                                                  new Product(444,"Pen",100)
                );
        List<Product> prdlist = productRepository.saveAll(productList);

         */

        /*Product product = productRepository.findById(111).get();
        System.out.println(product);

         */
        List<Product> productList = productRepository.findAll();
        productList.stream().forEach(System.out::println);
    }
}
