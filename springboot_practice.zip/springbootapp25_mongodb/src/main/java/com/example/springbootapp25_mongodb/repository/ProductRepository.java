package com.example.springbootapp25_mongodb.repository;

import com.example.springbootapp25_mongodb.beans.Product;
import org.springframework.data.mongodb.repository.MongoRepository;

public interface ProductRepository extends MongoRepository<Product,Integer> {
}
