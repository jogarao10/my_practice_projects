package com.example.springbootapp25_mongodb;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Springbootapp25MongodbApplication {

    public static void main(String[] args) {
        SpringApplication.run(Springbootapp25MongodbApplication.class, args);
    }

}
