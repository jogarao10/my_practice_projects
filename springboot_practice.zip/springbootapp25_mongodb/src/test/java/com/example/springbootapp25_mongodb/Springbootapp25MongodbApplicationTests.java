package com.example.springbootapp25_mongodb;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Springbootapp25MongodbApplicationTests {

    @Test
    void contextLoads() {
    }

}
