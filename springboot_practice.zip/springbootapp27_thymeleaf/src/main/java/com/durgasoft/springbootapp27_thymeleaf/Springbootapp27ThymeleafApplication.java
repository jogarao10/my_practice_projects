package com.durgasoft.springbootapp27_thymeleaf;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Springbootapp27ThymeleafApplication {

    public static void main(String[] args) {
        SpringApplication.run(Springbootapp27ThymeleafApplication.class, args);
    }

}
