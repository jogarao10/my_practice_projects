package com.durgasoft.springbootapp27_thymeleaf;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Springbootapp27ThymeleafApplicationTests {

    @Test
    void contextLoads() {
    }

}
