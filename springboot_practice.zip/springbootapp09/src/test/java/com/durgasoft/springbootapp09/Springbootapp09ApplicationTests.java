package com.durgasoft.springbootapp09;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Springbootapp09ApplicationTests {

    @Test
    void contextLoads() {
    }

}
