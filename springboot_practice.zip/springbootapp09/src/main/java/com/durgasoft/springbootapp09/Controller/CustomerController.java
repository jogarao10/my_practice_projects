package com.durgasoft.springbootapp09.Controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.PropertySource;
import org.springframework.core.env.Environment;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@PropertySource("classpath:customer.properties")
@RestController
public class CustomerController {
    @Autowired
    private Environment environment;
    @RequestMapping("/cust")
    public String getCustomerDetails(){
        String data = "<h1>";
        data = data + environment.getProperty("customer.cno")+", ";
        data = data + environment.getProperty("customer.cname")+",";
        data = data + environment.getProperty("customer.caddr")+",";
        return data;
    }
}
