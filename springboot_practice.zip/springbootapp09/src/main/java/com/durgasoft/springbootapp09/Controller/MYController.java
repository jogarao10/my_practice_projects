package com.durgasoft.springbootapp09.Controller;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.PropertySource;
import org.springframework.context.annotation.PropertySources;
import org.springframework.core.env.Environment;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

//@PropertySource({"classpath:customer.properties", "classpath:employee.properties", "classpath:customer.properties"})
@PropertySources(
        {
                @PropertySource("classpath:customer.properties"),
                @PropertySource("classpath:student.properties"),
                @PropertySource("classpath:employee.properties")
        }
)
@RestController
public class MYController {
    @Autowired
    private Environment environment;
    @RequestMapping("/all")
    public String getAllDetails(){
        String customerdata = "<h1>" ;
        customerdata = customerdata + environment.getProperty("customer.cno")+", ";
        customerdata = customerdata + environment.getProperty("customer.cname")+", ";
        customerdata = customerdata + environment.getProperty("customer.caddr")+"<h1>";

        String studentdata = "<h1>";
        studentdata = studentdata + environment.getProperty("student.sid")+", ";
        studentdata = studentdata + environment.getProperty("student.sname")+", ";
        studentdata = studentdata + environment.getProperty("student.saddr")+"<h1>";

        String employeedata = "<h1>";
        employeedata = employeedata + environment.getProperty("employee.eid")+", ";
        employeedata = employeedata + environment.getProperty("employee.ename")+", ";
        employeedata = employeedata + environment.getProperty("employee.esal")+", ";
        employeedata = employeedata + environment.getProperty("employee.eaddr")+"<h1>";

        return customerdata + studentdata + employeedata
                ;
    }
}
