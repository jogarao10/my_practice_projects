package com.durgasoft.springbootapp23_paging_and_sorting;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Springbootapp23PagingAndSortingApplicationTests {

    @Test
    void contextLoads() {
    }

}
