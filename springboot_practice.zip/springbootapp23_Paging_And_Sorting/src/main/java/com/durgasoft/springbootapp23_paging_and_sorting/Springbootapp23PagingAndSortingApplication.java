package com.durgasoft.springbootapp23_paging_and_sorting;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Springbootapp23PagingAndSortingApplication {

    public static void main(String[] args) {
        SpringApplication.run(Springbootapp23PagingAndSortingApplication.class, args);
    }

}
