package com.durgasoft.springbootapp23_paging_and_sorting.runner;
import com.durgasoft.springbootapp23_paging_and_sorting.repository.studentRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.data.domain.Page;
import com.durgasoft.springbootapp23_paging_and_sorting.beans.student;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Component;
import com.durgasoft.springbootapp23_paging_and_sorting.repository.studentRepository;

@Component
public class studentRunner implements CommandLineRunner {
    @Autowired
    private studentRepository studentRepository;
    @Override
    public void run(String... args) throws Exception {
        /*Sort sort = Sort.by(Sort.Direction.fromString("ASC"),"sname");
        Iterable iterable = studentRepository.findAll(sort);
        iterable.forEach(System.out::println);

         */
        /*
        PageRequest pageRequest = PageRequest.of(0,3);
        Page<student> page = studentRepository.findAll(pageRequest);
        page.forEach(System.out::println);

         */
        PageRequest pageRequest = PageRequest.of(0,3,Sort.Direction.fromString("desc"),"sname");
        Page<student> page = studentRepository.findAll(pageRequest);
        page.forEach(System.out::println);
    }
}
