package com.durgasoft.springbootapp23_paging_and_sorting.repository;
import com.durgasoft.springbootapp23_paging_and_sorting.beans.student;

import org.springframework.data.repository.PagingAndSortingRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface studentRepository extends PagingAndSortingRepository<student,String> {

}
