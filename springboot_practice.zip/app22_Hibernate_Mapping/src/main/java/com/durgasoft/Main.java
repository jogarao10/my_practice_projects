package com.durgasoft;


import com.durgasoft.entites.Employee;
import org.hibernate.Filter;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.boot.registry.StandardServiceRegistryBuilder;
import org.hibernate.cfg.Configuration;

import java.util.List;
import java.util.Scanner;

public class Main {
    public static void main(String[] args){

        Configuration configuration = new Configuration();
        configuration.configure();

        SessionFactory sessionFactory = configuration.buildSessionFactory(
                new
                        StandardServiceRegistryBuilder().applySettings(configuration.getProperties()).build()
        );

        Session session = sessionFactory.openSession();
        Filter filter = session.enableFilter("empFilter");
        System.out.println("which address we want sort : TEMP || PERM");

        Scanner scanner = new Scanner(System.in);
        String type = scanner.next();
        filter.setParameter("type", type);
        Query query = session.createQuery("from Employee");
        List<Employee> empList = query.list();
        System.out.println("ENO\tENAME\tESAL\tEADDR\tETYPE");
        System.out.println("----------------------------");
        for (Employee emp: empList){
            System.out.print(emp.getEno()+"\t");
            System.out.print(emp.getEname()+"\t\t");
            System.out.print(emp.getEsal()+"\t");
            System.out.print(emp.getEaddr()+"\t\t");
            System.out.print(emp.getEtype()+"\n");
        }
        session.close();
        sessionFactory.close();


    }
}