package com.durgasoft.springbootapp11.Controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.PropertySource;
import org.springframework.core.env.Environment;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
@PropertySource("classpath:employee.properties")
@RestController
public class EmployeeController {
    @Autowired
    private Environment environment;
    @RequestMapping("/emp")
    public String getEmpoyeeDetails(){
        String data = "<h1> Employee Details : ";
        data = data + environment.getProperty("employee.eno")+", ";
        data = data + environment.getProperty("employee.ename")+", ";
        data = data + environment.getProperty("employee.esal")+", ";
        data = data + environment.getProperty("employee.eaddr")+"<h1>";

        return data;
    }
}
