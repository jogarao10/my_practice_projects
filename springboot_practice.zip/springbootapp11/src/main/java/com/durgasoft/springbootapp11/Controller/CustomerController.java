package com.durgasoft.springbootapp11.Controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.PropertySource;
import org.springframework.core.env.Environment;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@PropertySource("file:./customer.properties")
@RestController
public class CustomerController {
    @Autowired
    private Environment environment;
    @RequestMapping("/cust")
    public String getCustomerDetails(){
        String data = "<h1> Customer Details :  ";
        data = data + environment.getProperty("customer.cid")+", ";
        data = data + environment.getProperty("customer.cname")+", ";
        data = data + environment.getProperty("customer.caddr")+"<h1>";

        return data;
    }
}
