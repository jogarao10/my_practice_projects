package com.durgasoft.springbootapp11.Controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.PropertySource;
import org.springframework.core.env.Environment;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
@PropertySource("classpath:config/student.properties")
@RestController
public class StudentController {
    @Autowired
    private Environment environment;
    @RequestMapping("/std")
    public String getStudentDetails(){
        String data = "<h1> Student Details : ";
        data = data + environment.getProperty("student.sid")+", ";
        data = data + environment.getProperty("student.sname")+", ";
        data = data + environment.getProperty("student.saddr")+"<h1>";

        return data;
    }
}
