package com.durgasoft.springbootapp11.Controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.PropertySource;
import org.springframework.core.env.Environment;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
@PropertySource("file:./config/client.properties")
@RestController
public class ClientController {

    @Autowired
    private Environment environment;
    @RequestMapping("/clt")
    public String getClientDetails(){
        String data = "<h1> Client Details  : ";
        data = data + environment.getProperty("client.cid")+", ";
        data = data + environment.getProperty("client.cname")+", ";
        data = data + environment.getProperty("client.caddr")+"<h1>";
        return data;
    }
}
