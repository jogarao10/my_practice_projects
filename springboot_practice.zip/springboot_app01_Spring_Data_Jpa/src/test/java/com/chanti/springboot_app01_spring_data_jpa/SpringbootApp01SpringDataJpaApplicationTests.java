package com.chanti.springboot_app01_spring_data_jpa;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringbootApp01SpringDataJpaApplicationTests {

    @Test
    void contextLoads() {
    }

}
