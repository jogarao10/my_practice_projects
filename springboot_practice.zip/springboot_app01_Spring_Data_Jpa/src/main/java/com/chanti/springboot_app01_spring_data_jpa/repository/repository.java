package com.chanti.springboot_app01_spring_data_jpa.repository;
import com.chanti.springboot_app01_spring_data_jpa.beans.product;


public interface Productrepository extends JpaRepository< Productrepository, Integer> {

}
