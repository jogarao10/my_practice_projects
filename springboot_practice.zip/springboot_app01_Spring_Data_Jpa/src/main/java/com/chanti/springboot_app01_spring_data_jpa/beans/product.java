package com.chanti.springboot_app01_spring_data_jpa.beans;

import jakarta.persistence.*;

@Entity
@Table(name="product")
public class product {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "pid")
    private int pid;
    @Column(name = "pname")
    private String pname;
    @Column(name = "pcost")
    private int pcost;

}
