package com.durgasoft.springbootapp25_spring_web;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Springbootapp25SpringWebApplication {

    public static void main(String[] args) {
        SpringApplication.run(Springbootapp25SpringWebApplication.class, args);
    }

}
