package com.durgasoft.springbootapp25_spring_web;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Springbootapp25SpringWebApplicationTests {

    @Test
    void contextLoads() {
    }

}
