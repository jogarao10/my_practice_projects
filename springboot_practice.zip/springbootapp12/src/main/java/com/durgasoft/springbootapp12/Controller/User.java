package com.durgasoft.springbootapp12.Controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.PropertySource;
import org.springframework.context.annotation.PropertySources;
import org.springframework.core.env.Environment;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@PropertySources({

        @PropertySource("classpath:./Config/user.properties"),
        @PropertySource("file:./user.properties"),
        @PropertySource("file:./Config/user.properties"),
        @PropertySource("classpath:user.properties")
})
@RestController
public class User {
    @Autowired
    private Environment environment;
    @RequestMapping("/user")
    public String getUserDetails(){
        String data = "<h1> Message Information :  ";
        data = data + environment.getProperty("message")+"</h1> ";


        return data;
    }
}
