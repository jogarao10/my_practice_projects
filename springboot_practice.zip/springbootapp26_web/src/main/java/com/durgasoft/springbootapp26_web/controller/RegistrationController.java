package com.durgasoft.springbootapp26_web.controller;

import com.durgasoft.springbootapp26_web.model.Registration;
import com.durgasoft.springbootapp26_web.service.RegistrationService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
@RequestMapping("/registration")
public class RegistrationController {
    @Autowired
    private RegistrationService registrationService;

    @RequestMapping("/")
    public String showSignupPage(){
        return "signup";
    }

    @RequestMapping("/registrationform")
    public String showRegistrationForm(Model model){
        model.addAttribute("registration", new Registration());
        return "registrationForm";
    }

    @RequestMapping("/save")
    public String saveRegistration(@ModelAttribute Registration registration, Model model){
        Registration rg = registrationService.saveRegistration(registration);
        if(rg.getAdminno() == registration.getAdminno()){
            model.addAttribute("status1","Register Successfully");
        }else{
            model.addAttribute("status1","Registration Failure");
        }
        return "status1";
    }



}
