package com.durgasoft.springbootapp26_web.controller;

import com.durgasoft.springbootapp26_web.model.Product;
import com.durgasoft.springbootapp26_web.service.ProductService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
@RequestMapping("/product")
public class ProductController {
    @Autowired
    private ProductService productService;



    @RequestMapping("/")
    public String showWelcomePage(){
        return "welcome";
    }

    @RequestMapping("/addform")
    public String showAddForm(Model model){
        model.addAttribute("product", new Product());
        return "addform";
    }
    @RequestMapping("/searchform")
    public String showSearchForm(Model model){
        model.addAttribute("product",new Product());
        return "searchform";
    }


    @RequestMapping("/save")
    public String saveProduct(@ModelAttribute Product product,Model model){
        Product prd = productService.saveProduct(product);
        if(prd.getPid() == product.getPid()){
            model.addAttribute("status","Product Inserted Successfully");
        }else{
            model.addAttribute("status","Product Insertion Failure");
        }
        return "status";
    }
    @RequestMapping("/search")
    public String searchProduct(@ModelAttribute Product product,Model model){
        Product product1 = productService.searchProduct(product.getPid());
        model.addAttribute("product",product1);
        return "productDetails";
    }

}
