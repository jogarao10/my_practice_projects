package com.durgasoft.springbootapp26_web.service;

import com.durgasoft.springbootapp26_web.ProductRepository.RegistrationRepository;
import com.durgasoft.springbootapp26_web.model.Registration;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
public class RegistrationServiceImpl implements RegistrationService{
    @Autowired
    private RegistrationRepository registrationRepository;
    @Transactional
    @Override
    public Registration saveRegistration(Registration registration) {
        Registration registration1 = registrationRepository.save(registration);
        return registration1;
    }
}
