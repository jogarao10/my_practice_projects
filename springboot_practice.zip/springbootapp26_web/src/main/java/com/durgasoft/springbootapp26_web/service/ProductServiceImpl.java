package com.durgasoft.springbootapp26_web.service;

import com.durgasoft.springbootapp26_web.ProductRepository.ProductRepository;
import com.durgasoft.springbootapp26_web.ProductRepository.RegistrationRepository;
import com.durgasoft.springbootapp26_web.model.Product;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
public class ProductServiceImpl implements ProductService {
    @Autowired
    private ProductRepository productRepository;


    @Transactional
    @Override
    public Product saveProduct(Product product) {
        Product product1 = productRepository.save(product);
        return product1;
    }

    @Override
    public Product searchProduct(int pid) {
        Product product = productRepository.findProductByPid(pid);
        return product;
    }

}
