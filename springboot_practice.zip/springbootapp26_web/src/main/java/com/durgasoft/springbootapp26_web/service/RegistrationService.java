package com.durgasoft.springbootapp26_web.service;

import com.durgasoft.springbootapp26_web.model.Registration;

public interface RegistrationService{
    public Registration saveRegistration(Registration registration);
}
