package com.durgasoft.springbootapp26_web.service;

import com.durgasoft.springbootapp26_web.model.Product;

public interface ProductService {
    public Product saveProduct(Product product);
    public Product searchProduct(int pid);
}
