package com.durgasoft.springbootapp26_web.ProductRepository;

import com.durgasoft.springbootapp26_web.model.Registration;
import org.springframework.data.jpa.repository.JpaRepository;

public interface RegistrationRepository extends JpaRepository<Registration,Integer> {

}
