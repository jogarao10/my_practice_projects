package com.durgasoft.springbootapp26_web.ProductRepository;

import com.durgasoft.springbootapp26_web.model.Product;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface ProductRepository extends JpaRepository<Product,Integer> {
    public Product findProductByPid(int pid);
}
