package com.durgasoft.springbootapp26_web.model;

import jakarta.persistence.*;

@Entity
@Table(name = "registration")
public class Registration {
    @Id
    private int adminno;
    private String adminname;
    private long mobile;
    private String mailid;
    private String password;

    public int getAdminno() {
        return adminno;
    }

    public void setAdminno(int adminno) {
        this.adminno = adminno;
    }

    public String getAdminname() {
        return adminname;
    }

    public void setAdminname(String adminname) {
        this.adminname = adminname;
    }

    public long getMobile() {
        return mobile;
    }

    public void setMobile(long mobile) {
        this.mobile = mobile;
    }

    public String getMailid() {
        return mailid;
    }

    public void setMailid(String mailid) {
        this.mailid = mailid;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    @Override
    public String toString() {
        return "Registration{" +
                "adminno=" + adminno +
                ", adminname='" + adminname + '\'' +
                ", mobile=" + mobile +
                ", mailid='" + mailid + '\'' +
                ", password='" + password + '\'' +
                '}';
    }
}