import java.lang.invoke.TypeDescriptor;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Types;

public class Main {
    public static void main(String[] args) {
        try (
                Connection connection = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:orcl", "SCOTT", "tiger");
                CallableStatement callableStatement = connection.prepareCall("{call getSal(?,?)}")
        ) {
            callableStatement.setInt(1, 111);
            callableStatement.registerOutParameter(2, Types.FLOAT);
            callableStatement.execute();
            System.out.println("Employee Salary  " + callableStatement.getFloat(2));

        } catch (Exception exception) {
            exception.printStackTrace();
        }

    }
}