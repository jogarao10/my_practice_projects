import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.util.logging.SocketHandler;

public class Main {
    public static void main(String[] args) {

        try(
                BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(System.in));
                Connection connection = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:orcl","SCOTT","tiger");
                PreparedStatement preparedStatement = connection.prepareStatement("delete from emp1 where esal < ?");
                )
        {
            System.out.println("Salary Range   :  ");
            Float esal = Float.parseFloat(bufferedReader.readLine());

            preparedStatement.setFloat(1,esal);

            int rowCount = preparedStatement.executeUpdate();
            System.out.println("Employee Records are delete successfully" +rowCount);


        } catch (Exception exception) {
            exception.printStackTrace();
        }

    }
}