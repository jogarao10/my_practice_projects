import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;

public class Main {
    public static void main(String[] args) {

        try(
                BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(System.in));
                Connection connection = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:orcl","SCOTT","tiger");
                PreparedStatement preparedStatement = connection.prepareStatement("insert into product values(?,?,?,?)")
                ) {
            System.out.print("PRODUCT NUMBER      :  ");
            String pid = bufferedReader.readLine();

            System.out.print("PRODUCT NAME        :  ");
            String pname = bufferedReader.readLine();

            System.out.print(" MANUFACTURING DATE :  ");
            java.sql.Date mfgDate = java.sql.Date.valueOf(bufferedReader.readLine());

            System.out.println("EXPIRY DATE       :  ");
            java.sql.Date expDate = java.sql.Date.valueOf(bufferedReader.readLine());

            preparedStatement.setString(1,pid);
            preparedStatement.setString(2,pname);
            preparedStatement.setDate(3,mfgDate);
            preparedStatement.setDate(4,expDate);

            int rowCount = preparedStatement.executeUpdate();

            if (rowCount==1) {
                System.out.println("product inserted successfully");
                System.out.println("Insert one more product[yes/no] :  ");
                String option = bufferedReader.readLine();
                if(option.equalsIgnoreCase("yes")){

                }



            }else {
            }

        } catch (Exception exception) {
            exception.printStackTrace();
        }

    }
}