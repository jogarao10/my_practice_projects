import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Types;

public class Main {
    public static void main(String[] args) {
        try(
                Connection connection = DriverManager.getConnection("jdbc:oracle:thin:localhost:1521:orcl","SCOTT","tiger");
                CallableStatement callableStatement = connection.prepareCall("{? = call getAVG ?,?}");

        ) {
            callableStatement.setInt(2,111);
            callableStatement.setInt(3,222);
            callableStatement.registerOutParameter(1, Types.FLOAT);
            callableStatement.execute();
            System.out.println("AVG salary of Employees 111, 222  "+callableStatement.getFloat(1));

        } catch (Exception exception) {
            exception.printStackTrace();
        }



    }
}