import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;

public class Main {
    public static void main(String[] args) {

        try(
                Connection connection = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:orcl","SCOTT","tiger");
                Statement statement = connection.createStatement();
                ) {
              statement.addBatch("insert into emp1 values(111,'AAA',5000,'HYD')");
              statement.addBatch("insert into emp1 values(222,'BBB',6000,'HYD')");
              statement.addBatch("insert into emp1 values(333,'CCC',7000,' HYD')");

            //statement.addBatch("delete from emp1 where eno = 111");
            //statement.addBatch("delete from emp1 where eno = 222");



            int[] rowCounts = statement.executeBatch();
            for (int rowCount: rowCounts){
                System.out.println("RowCount  : "+rowCount);
            }

        } catch (Exception exception) {
            exception.printStackTrace();
        }

    }
}