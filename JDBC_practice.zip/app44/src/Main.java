import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;


public class Main {
    public static void main(String[] args){

        try(
                BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(System.in));
                Connection connection = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:orcl","SCOTT","tiger");
                PreparedStatement preparedStatement = connection.prepareStatement("select * from emp1");
                ResultSet resultSet = preparedStatement.executeQuery();

                ) {

            System.out.println("ENO\tENAME\t ESAL\t EADDR");
            System.out.println("-------------------------------");
            while(resultSet.next()){
                System.out.print(resultSet.getInt("ENO")+"\t");
                System.out.print(resultSet.getString("ENAME")+"\t");
                System.out.print(resultSet.getFloat("ESAL")+"\t");
                System.out.print(resultSet.getString("EADDR")+"\n");
                System.out.println("1");
            }
            System.out.println("12");


        } catch (Exception exception) {
            exception.printStackTrace();
        }



    }
}