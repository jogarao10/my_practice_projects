import org.apache.commons.dbcp2.BasicDataSource;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;

public class Main {
    public static void main(String[] args) {

        BasicDataSource basicDataSource = null;
        Connection connection = null;
        Statement statement = null;
        ResultSet resultSet = null;
        try {
            basicDataSource = new BasicDataSource();
            basicDataSource.setDriverClassName("oracle.jdbc.OracleDriver");
            basicDataSource.setUrl("jdbc:oracle:thin:@localhost:1521:orcl");
            basicDataSource.setUsername("SCOTT");
            basicDataSource.setPassword("tiger");


            basicDataSource.setInitialSize(2);
            basicDataSource.setMaxTotal(4);

            connection = basicDataSource.getConnection();
            statement = connection.createStatement();
            resultSet = statement.executeQuery("select * from emp1");

            System.out.println("ENNO\tENAME\tESAL\tEADDR");
            System.out.println("-------------------------------");

            while (resultSet.next()){
                System.out.print(resultSet.getInt("ENO")+"\t\t");
                System.out.print(resultSet.getString("ENAME")+"\t\t");
                System.out.print(resultSet.getFloat("ESAL")+"\t");
                System.out.print(resultSet.getString("EADDR")+"\n");


            }

        } catch (Exception exception) {
            exception.printStackTrace();
        }finally {
            try {
                connection.close();
            } catch (Exception exception) {
                exception.printStackTrace();
            }

        }


    }
}