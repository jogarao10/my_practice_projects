import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;

public class Main {
    public static void main(String[] args) {

        Connection connection = null;
        Statement statement = null;
        try {
            connection = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:orcl","SCOTT","tiger");
            connection.setAutoCommit(false);
            statement = connection.createStatement();
            statement.executeUpdate("insert into student values('s1','SUSANTH',97)");
            statement.executeUpdate("insert into student values('s2','CHANTI','77')");
            connection.commit();
            System.out.println("Transation is SUCCESS");
        } catch (Exception exception) {
            try {
                connection.rollback();
                System.out.println("Transation is FAILUARE");
            } catch (SQLException e) {
                e.printStackTrace();
            }
            exception.printStackTrace();
        }
        finally {
            try {
                connection.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
    }
}