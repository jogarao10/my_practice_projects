import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;

public class Main {
    public static void main(String[] args) {

        try (
                Connection connection = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:orcl","SCOTT","tiger");
                PreparedStatement preparedStatement = connection.prepareStatement("insert into emp25 values (?,?,?,?)");

                ){

            preparedStatement.setInt(1,111);
            preparedStatement.setString(2,"Susanth");
            preparedStatement.setDate(3,java.sql.Date.valueOf("2012-11-12"));
            preparedStatement.setDate(4,new java.sql.Date(new java.util.Date().getTime()));
            preparedStatement.executeUpdate();
            System.out.println("Employee Details Inserted Successfully");


            preparedStatement.setInt(1,222);
            preparedStatement.setString(2,"harsith");
            preparedStatement.setDate(3,java.sql.Date.valueOf("2014-05-25"));
            preparedStatement.setDate(4,new java.sql.Date(new java.util.Date().getTime()));

            preparedStatement.executeUpdate();
            System.out.println("Employee 222 Inserted Successfully");


        } catch (Exception exception) {
            exception.printStackTrace();
        }

    }
}