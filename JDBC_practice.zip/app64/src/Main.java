import oracle.jdbc.pool.OracleDataSource;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;

public class Main {
    public static void main(String[] args) {
        OracleDataSource oracleDataSource = null;
        Connection connection = null;
        Statement statement = null;
        ResultSet resultSet = null;

        try {
            oracleDataSource = new OracleDataSource();
            //oracleDataSource.setDriverType("oracle.jdbc.oracleDriver");
            oracleDataSource.setURL("jdbc:oracle:thin:@localhost:1521:orcl");
            oracleDataSource.setUser("SCOTT");
            oracleDataSource.setPassword("tiger");

            connection = oracleDataSource.getConnection();
            statement = connection.createStatement();
            resultSet = statement.executeQuery("select * from emp1");

            System.out.println("ENO\tENAME\tESAL\tEADDR");



            System.out.println("---------------------------");
            while (resultSet.next()){
                System.out.print(resultSet.getInt("ENO")+"\t");
                System.out.print(resultSet.getString("ENAME")+"\t");
                System.out.print(resultSet.getFloat("ESAL")+"\t");
                System.out.print(resultSet.getString("EADDR")+"\n");


            }
        } catch (Exception exception) {
            exception.printStackTrace();
        }finally {
            try {
                    connection.close();
            } catch (Exception exception) {
                exception.printStackTrace();
            }

        }


    }
}