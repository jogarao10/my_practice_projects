import oracle.jdbc.OracleTypes;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;

public class Main {
    public static void main(String[] args) {
        try(
                Connection connection = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:orcl","SCOTT","tiger");
                CallableStatement callableStatement = connection.prepareCall("{call getAllEmployees(?) }");
        ){
                callableStatement.registerOutParameter(1,OracleTypes.CURSOR);
                callableStatement.execute();
                ResultSet resultSet = (ResultSet) callableStatement.getObject(1);
            System.out.println("ENO\tENAME\tESAL\tEADDR");
            System.out.println("-------------------------------");
            while (resultSet.next()){
                System.out.print(resultSet.getInt("ENO")+"\t");
                System.out.print(resultSet.getString("ENAME")+"\t");
                System.out.print(resultSet.getFloat("ESAL")+"\t");
                System.out.println(resultSet.getString("Eaddr"));
            }



        } catch (Exception exception) {
            exception.printStackTrace();
        }


    }
}