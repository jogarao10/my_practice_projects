class A{

     A(){
        System.out.println("A-CON");
    }

}
public class Main {
    public static void main(String[] args) {
        A a = new A();





    }
}