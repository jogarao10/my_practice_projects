import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;

public class Main {
    public static void main(String[] args) {

        Connection connection = null;
        Statement statement = null;
        try {
            connection = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:orcl","SCOTT","tiger");
            connection.setAutoCommit(false);
            statement = connection.createStatement();
            int rowCount1 = statement.executeUpdate("update account set ACCBALANCE = ACCBALANCE - 2000 where ACCNO = 'abc123'");
            int rowcount2 = statement.executeUpdate("update account set ACCBALANCE = ACCBALANCE + 3000 where ACCNO = 'xyz123'");
            if(rowCount1==1 && rowcount2==1) {
                connection.commit();
                System.out.println("Transaction SUCCESS");
            }else{
                connection.rollback();
                System.out.println("Transation FAILUARE");
            }
        } catch (Exception exception) {
            try {
                connection.rollback();
            } catch (SQLException e) {
                e.printStackTrace();
            }
            exception.printStackTrace();

        }
        finally {
            try {
                connection.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
    }
}