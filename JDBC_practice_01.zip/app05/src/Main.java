import com.durgasoft.app05.entities.Department;
import com.durgasoft.app05.entities.Employee;

public class Main {
    public static void main(String[] args) {
        Employee employee = new Employee();
        employee.setEmployeeId("1077");
        employee.setEmployeeName("Susanth");
        employee.setEmployeeSalary(100000);
        employee.setEmployeeAddres("Srikakulam");

        Employee employee1 = new Employee();
        employee1.setEmployeeId("7777");
        employee1.setEmployeeName("Harsith");
        employee1.setEmployeeSalary(200000);
        employee1.setEmployeeAddres("Srikakulam");

        Employee employee2 = new Employee();
        employee2.setEmployeeId("1000");
        employee2.setEmployeeName("Chanti");
        employee2.setEmployeeSalary(300000);
        employee2.setEmployeeAddres("Srikakulam");

        Employee[] employees = {employee,employee1,employee2};

        Department department = new Department();
        department.setDepartmentId("1010");
        department.setDepartmentName("Admin");
        department.setEmployees(employees);

        department.getDepartmentdetails();



    }
}