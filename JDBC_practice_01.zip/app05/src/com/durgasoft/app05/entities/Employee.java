package com.durgasoft.app05.entities;

public class Employee {
    private String employeeId;
    private String employeeName;
    private int employeeSalary;
    private String employeeAddres;

    public String getEmployeeId() {
        return employeeId;
    }

    public void setEmployeeId(String employeeId) {
        this.employeeId = employeeId;
    }

    public String getEmployeeName() {
        return employeeName;
    }

    public void setEmployeeName(String employeeName) {
        this.employeeName = employeeName;
    }

    public int getEmployeeSalary() {
        return employeeSalary;
    }

    public void setEmployeeSalary(int employeeSalary) {
        this.employeeSalary = employeeSalary;
    }

    public String getEmployeeAddres() {
        return employeeAddres;
    }

    public void setEmployeeAddres(String employeeAddres) {
        this.employeeAddres = employeeAddres;
    }
}
