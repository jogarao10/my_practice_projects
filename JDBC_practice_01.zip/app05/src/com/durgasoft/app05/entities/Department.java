package com.durgasoft.app05.entities;

public class Department {
    private String departmentId;
    private String departmentName;

    private Employee[] employees;

    public String getDepartmentId() {
        return departmentId;
    }

    public void setDepartmentId(String departmentId) {
        this.departmentId = departmentId;
    }

    public String getDepartmentName() {
        return departmentName;
    }

    public void setDepartmentName(String departmentName) {
        this.departmentName = departmentName;
    }

    public Employee[] getEmployees() {
        return employees;
    }

    public void setEmployees(Employee[] employees) {
        this.employees = employees;
    }


    public void getDepartmentdetails(){
        System.out.println("Department Details");
        System.out.println("--------------------------------");
        System.out.println("Department id     :"+departmentId);
        System.out.println("department Name   :"+departmentName);
        System.out.println("EmployeeId\tEmployeeName\tEmployeeSalary\tEmployeeAddres");
        System.out.println("----------------------------------------------------------------------");
        for (Employee employee:employees) {
            System.out.print(employee.getEmployeeId()+"\t\t");
            System.out.print(employee.getEmployeeName()+"\t\t\t");
            System.out.print(employee.getEmployeeSalary()+"\t\t\t");
            System.out.print(employee.getEmployeeAddres()+"\n");

        }
    }
}
