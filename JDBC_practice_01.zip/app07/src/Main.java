import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class Main {
    public static void main(String[] args) {


        Pattern pattern = Pattern.compile("[a-z]-[\\w]");
        Matcher matcher = pattern.matcher("aSa4#");

        if(matcher.find()==true){
            System.out.println("valid");
        }else {
            System.out.println("Invalid");
        }

    }
}