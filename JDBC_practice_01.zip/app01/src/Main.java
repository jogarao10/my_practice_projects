


import com.durgasoft.app02.entities.Account;
import com.durgasoft.app02.entities.Employee;

public class Main

{
    public static void main(String[] args)
    {

        Account account = new Account("abc123","Durga","savings",100000);
        Employee employee = new Employee(177,"Susanth",52000,"Srikakulam",account);
        employee.getEmployeeDetails();

    }
}