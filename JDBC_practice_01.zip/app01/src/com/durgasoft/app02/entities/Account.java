

package com.durgasoft.app02.entities;

public class Account {
    private String AccountNo;
    private String AccountHolderName;
    private String AccountType;
    private int Balance;

    public Account(String accountNo, String accountHolderName, String accountType, int balance) {
        this.AccountNo = accountNo;
        this.AccountHolderName = accountHolderName;
        this.AccountType = accountType;
        this.Balance = balance;
    }
    public void getAccountDetails()
    {
        System.out.println("Account Details");
        System.out.println("--------------------------");
        System.out.println("Account Number     :"+AccountNo);
        System.out.println("AccountHolderName  :"+AccountHolderName);
        System.out.println("Account Type       :"+AccountType);
        System.out.println("Account Balance    :"+Balance);

    }

}
