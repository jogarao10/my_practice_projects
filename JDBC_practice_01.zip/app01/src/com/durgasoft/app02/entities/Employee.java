package com.durgasoft.app02.entities;
public class Employee {
    private int empNo;
    private String empName;
    private float empSalary;
    private String empAddr;

    private Account account;  // one-to-one association

    public Employee(int empNo, String empName, float empSalary, String empAddr, Account account) {
        this.empNo = empNo;
        this.empName = empName;
        this.empSalary = empSalary;
        this.empAddr = empAddr;
        this.account = this.account;
    }

    public void getEmployeeDetails()
    {
        System.out.println("Employee Details");
        System.out.println("---------------------");
        System.out.println("Employee Number    :"+empNo);
        System.out.println("Employee Name      :"+empName);
        System.out.println("Employee Salary    :"+empSalary);
        System.out.println("Employee Address   :"+empAddr);
        System.out.println();
        account.getAccountDetails();


    }



}
















