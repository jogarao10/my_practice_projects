package com.durgasoft.app04.entities;

public class Employee {
    private String employeeId;
    private String employeeName;
    private float employeeSalary;
    private String employeeAddres;

    public Employee(String employeeId, String employeeName, float employeeSalary, String employeeAddres) {
        this.employeeId = employeeId;
        this.employeeName = employeeName;
        this.employeeSalary = employeeSalary;
        this.employeeAddres = employeeAddres;
    }

    public void getEmployeeDetails()
    {

        System.out.print(employeeId+"\t\t");
        System.out.print(employeeName+"\t\t\t");
        System.out.print(employeeSalary+"\t\t");
        System.out.print(employeeAddres+"\n");

    }
}
