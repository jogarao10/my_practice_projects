import com.durgasoft.app04.entities.Department;
import com.durgasoft.app04.entities.Employee;

public class Main {
    public static void main(String[] args) {

        Employee employee1 = new Employee("1077","Susanth",100000,"Srikakulam");
        Employee employee2 = new Employee("1234","Harsith",200000,"Srikakulam");
        Employee employee3 = new Employee("1033","Chanti",300000,"Srikakulam");
        Employee employee4 = new Employee("7777","Santhosh",400000,"Srikakulam");


        Employee[] employees = {employee1,employee2,employee3,employee4};

        Department department = new Department("7733","Admin",employees);
        department.getDepartmentDetails();
    }
}