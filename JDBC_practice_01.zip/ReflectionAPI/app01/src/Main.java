class C{
    public void m2(int... x){
        System.out.println("parent");

    }
}
class D extends C{
    public void m2(int x){
        System.out.println("child");
    }
}

public class Main {

    public static void main(String[] args) {
        C c = new D();
        c.m2();




    }
}