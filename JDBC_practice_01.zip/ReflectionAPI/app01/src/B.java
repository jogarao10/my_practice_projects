public class B {
    public void m1(){
        System.out.println("m2");
    }
}
