/*interface I{
    void m1();
    void m2();
    void m3();
}class A implements I{
    @Override
    public void m1() {
        System.out.println("m1-A");
    }

    @Override
    public void m2() {
        System.out.println("m2-A");
    }

    @Override
    public void m3() {
        System.out.println("m3-A");
    }
}
public class Main {
    public static void main(String[] args) {
        I i = new A();
        i.m1();
        i.m2();
        i.m3();
        System.out.println("  ");
        A a = new A();
        a.m1();

        a.m2();
        a.m3();




    }
}*/
/*interface I1{
    void m1();
}
interface I2{
    void m2();
}
interface I3{
    void m3();
}
class A implements I1,I2,I3{
    @Override
    public void m1() {
        System.out.println("m1-A");
    }

    @Override
    public void m2() {
        System.out.println("m2-A");
    }

    @Override
    public void m3() {
        System.out.println("m3-A");
    }
}

public class Main {
    public static void main(String args[]){
        I1 i = new A();
        i.m1();

        A a = new A();
        a.m1();
        a.m2();
        a.m3();


    }
}*/
/*interface I{
    void m1();
    void m2();
    void m3();
}
interface I1{
    void m4();
}
interface I2 extends I,I1{
    void m5();


}
class A implements I2{


    @Override
    public void m1() {
        System.out.println("m1-A");
    }

    @Override
    public void m2() {
        System.out.println("m2-A");

    }

    @Override
    public void m3() {
        System.out.println("m3-A");

    }

    @Override
    public void m4() {
        System.out.println("m4-A");

    }

    @Override
    public void m5() {
        System.out.println("m5-A");

    }
}

public class Main {
    public static void main(String[] args){

        I2 a = new A();
        a.m1();
        a.m2();
        a.m3();
        a.m4();
        a.m5();




    }
}*/
interface I1{
    void m1();
    void m2();
    void m3();

}
class A implements I1 {

    @Override
    public void m1() {
        System.out.println("m1-A");


    }

    @Override
    public void m2() {

    }

    @Override
    public void m3() {

    }
}
class B extends A{
    @Override
    public void m2() {
        System.out.println("m2-B");

    }
    public void m5(){

    }

    @Override
    public void m3() {

    }
}
public class Main {
    public static void main(String[] args){
        A a = new A();
        a.m1();
        a.m2();

    }
}