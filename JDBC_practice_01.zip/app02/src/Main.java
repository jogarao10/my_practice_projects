import com.durgasoft.app02.entities.Account;
import com.durgasoft.app02.entities.Employee;

public class Main {
    public static void main(String[] args) {

        Account account = new Account();
        account.setAccNo("1077");
        account.setAccHoldName("Susanth");
        account.setAccType("Savings");
        account.setAccBalance(100000);

       /* Account account1 = new Account();
        account1.setAccNo("1077");
        account1.setAccHoldName("Susanth");
        account1.setAccType("Savings");
        account1.setAccBalance(100000);*/


        Employee employee = new Employee();
        employee.setEmpNo(10777);
        employee.setEmpName("Harsith");
        employee.setEmpsal(52000);
        employee.setEmpAddr("Srikakulam");

      /*  Employee employee1 = new Employee();
        employee1.setEmpNo(10777);
        employee1.setEmpName("Harsith");
        employee1.setEmpsal(52000);
        employee1.setEmpAddr("Srikakulam");*/


        employee.setAccount(account);   // one-to-one
       // employee1.setAccount(account1);

        employee.getEmployeeDetails();
       // employee1.getEmployeeDetails();

    }
}