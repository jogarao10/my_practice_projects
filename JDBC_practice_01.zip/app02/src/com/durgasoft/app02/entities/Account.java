package com.durgasoft.app02.entities;

public class Account {
    private String accNo;
    private String accHoldName;
    private String accType;
    private int accBalance;

    public String getAccNo() {
        return accNo;
    }

    public void setAccNo(String accNo) {
        this.accNo = accNo;
    }

    public String getAccHoldName() {
        return accHoldName;
    }

    public void setAccHoldName(String accHoldName) {
        this.accHoldName = accHoldName;
    }

    public String getAccType() {
        return accType;
    }

    public void setAccType(String accType) {
        this.accType = accType;
    }

    public int getAccBalance() {
        return accBalance;
    }

    public void setAccBalance(int accBalance) {
        this.accBalance = accBalance;
    }
}
