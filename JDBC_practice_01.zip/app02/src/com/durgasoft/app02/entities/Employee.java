package com.durgasoft.app02.entities;

public class Employee {
    private int empNo;
    private String empName;
    private float empsal;
    private String empAddr;

    private Account account;

    public int getEmpNo() {
        return empNo;
    }

    public void setEmpNo(int empNo) {
        this.empNo = empNo;
    }

    public String getEmpName() {
        return empName;
    }

    public void setEmpName(String empName) {
        this.empName = empName;
    }

    public float getEmpsal() {
        return empsal;
    }

    public void setEmpsal(float empsal) {
        this.empsal = empsal;
    }

    public String getEmpAddr() {
        return empAddr;
    }

    public void setEmpAddr(String empAddr) {
        this.empAddr = empAddr;
    }

    public Account getAccount() {
        return account;
    }

    public void setAccount(Account account) {
        this.account = account;
    }


    public void getEmployeeDetails()
    {
        System.out.println("Employee Details");
        System.out.println("-----------------------------");
        System.out.println("Employee Number    :"+empNo);
        System.out.println("Employee Name      :"+empName);
        System.out.println("Employee Salary    :"+empsal);
        System.out.println("Employee Addres    :"+empAddr);
        System.out.println();

        System.out.println("Account Details");
        System.out.println("-------------------------------");
        System.out.println("Account Number     :"+account.getAccNo());
        System.out.println("Account Holder Name:"+account.getAccHoldName());
        System.out.println("Account Type       :"+account.getAccType());
        System.out.println("Account Balance    :"+account.getAccBalance());







    }
}
