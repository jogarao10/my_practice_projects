import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        System.out.println("Enter your number : ");
        Scanner scanner = new Scanner(System.in);
        int number = scanner.nextInt();
        if (number % 2 == 0){
            System.out.println("Even number ");
        }else {
            System.out.println("Odd number ");
        }
    }
}