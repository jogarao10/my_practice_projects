import java.util.Scanner;
import java.util.*;

public class Main {
    public static void main(String[] args) {
        double a,b,c;
        System.out.println("Enter your a value : ");
        Scanner scanner = new Scanner(System.in);
        a = scanner.nextDouble();
        System.out.println("Enter your b value : ");
        b = scanner.nextDouble();
        System.out.println("Enter your c value : ");
        c = scanner.nextDouble();
        double d = (b*b - 4.0 * a * c);
        if(d>0){
            double r1 = (-b + Math.sqrt(d))/(2.0 * a);
            double r2 = (-b - Math.sqrt(d))/(2.0 * a);
            System.out.println(" first root is : "+r1);
            System.out.println(" second root is : "+r2);
        } else if (d==0) {
            double r = (-b)/(2*a);
            System.out.println("Roots are equal : "+r);

        }else if (d<0){
            double r1 = (-b)/(2*a);
            double r2 = (Math.sqrt(-d)/(2*a));
            System.out.println("Roots are Imaginary");
            System.out.println("real number is : "+r1);
            System.out.println("Imaginary number is : "+r2);
        }
    }
}