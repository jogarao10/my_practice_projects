import java.util.Scanner;

public class Main {
    public static void main(String[] args) {

        int number;
        System.out.println("Enter Number : ");
        Scanner scanner = new Scanner(System.in);
        number = scanner.nextInt();
        int temp, reminder = 0, sum = 0;
        temp = number;
        while (number != 0){
            reminder = number % 10;
            sum = sum+(reminder*reminder*reminder);
            number = number/10;
        }
        if (sum == temp){
            System.out.println("Given number is Amstrong number : "+sum);
        }else {
            System.out.println("Given number is Not a Amstrong number");
        }
    }
}