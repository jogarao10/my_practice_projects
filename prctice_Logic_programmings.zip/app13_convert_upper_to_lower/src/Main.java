import java.util.Scanner;

public class Main {
    public static void main(String[] args) {

        char c1;
        System.out.println("Enter your character : ");
        Scanner scanner = new Scanner(System.in);
        c1 = scanner.next().charAt(0);

        if(97<=c1 && c1<=122) {
            int ascii = c1 - 32;
            char c2 = (char) ascii;
            System.out.println("Upper letter : " + c2);
        } else if (65<=c1 && c1<=91) {
            int ascii = c1 + 32;
            char c2 = (char) ascii;
            System.out.println("Lower Letter : " + c2);

        }
    }
}