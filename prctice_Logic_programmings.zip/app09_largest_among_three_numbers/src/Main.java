import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        double first_Number, second_Number, third_Number;
        System.out.print("Enter your first number  : ");
        Scanner scanner = new Scanner(System.in);
        first_Number = scanner.nextDouble();
        System.out.print("Enter your second number  : ");
        second_Number = scanner.nextDouble();
        System.out.print("Enter your third number  : ");
        third_Number = scanner.nextDouble();

        /*if (first_Number > second_Number && first_Number > third_Number){
            System.out.println("first number is Largest number : "+first_Number);
        } else if (second_Number > first_Number && second_Number > third_Number) {
            System.out.println("second number is Largest number : "+second_Number);
        }else if(third_Number > first_Number && third_Number > second_Number){
            System.out.println("third number is Largest number : "+third_Number);
        }else{
            System.out.println("All Three numbers are equal ");
        }*/


    }
}