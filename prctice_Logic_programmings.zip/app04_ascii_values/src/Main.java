public class Main {
    public static void main(String[] args) {
        for (int i=65; i<=128; i++){
            System.out.println(i +" : " +(char)i);

        }

    }
}