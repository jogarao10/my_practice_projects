import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        int num;
        int firstValue=0 , secondValue=1;
        System.out.println("Enter your number : ");
        Scanner scanner = new Scanner(System.in);
        num = scanner.nextInt();
        for(int i = 1; i<=num;++i){
            System.out.println("Fibonacci series is : "+firstValue);
            int nextValue = firstValue + secondValue;
            firstValue = secondValue;
            secondValue = nextValue;

        }

    }
}