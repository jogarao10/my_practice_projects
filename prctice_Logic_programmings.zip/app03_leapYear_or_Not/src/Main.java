import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        int year;
        System.out.print("Enter your year : ");
        Scanner scanner = new Scanner(System.in);
        year = scanner.nextInt();
        if (year%4 == 0 && year%100 != 0 || year%400 == 0){
            System.out.println("Given year is leap year : "+year);
        } /*else if (year%4 == 0 && year%100 != 0) {
            System.out.println("Given year is leap year : "+year);
        }*/else {
            System.out.println("Given year is not leap year : "+year);
        }

    }
}