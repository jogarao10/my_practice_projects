import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        double first_Number;
        double second_Number;
        System.out.println("Enter your first number : ");
        System.out.println("Enter your second number : ");
        Scanner scanner = new Scanner(System.in);
        first_Number = scanner.nextDouble();
        second_Number = scanner.nextDouble();

        /*double temp;
        temp = first_Number;
        first_Number = second_Number;
        second_Number = temp;
        System.out.println("===========================");
        System.out.print("After swip "+first_Number+" , "+second_Number);

         */
        first_Number = first_Number + second_Number;
        second_Number = first_Number - second_Number;
        first_Number = first_Number - second_Number;
        System.out.println("===========================");
        System.out.print("After swip "+first_Number+" , "+second_Number);



    }
}