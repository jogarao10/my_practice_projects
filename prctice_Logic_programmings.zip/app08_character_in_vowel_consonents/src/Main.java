import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        char a;
        System.out.println("Enter your character : ");
        Scanner scanner = new Scanner(System.in);
        a = scanner.next().charAt(0);

        switch (a){
            case 'a':
            case 'e':
            case 'i':
            case 'o':
            case 'u':
                System.out.println("Your character is "+a+" vowel");
                break;
            default:
                System.out.println("Your character is "+a+" consonant");
        }
    }
}