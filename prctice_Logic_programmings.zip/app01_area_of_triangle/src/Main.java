public class Main {
    public static void main(String[] args) {


        int breath = 10;
        int height = 10;
        double area = 0.5 * breath * height;
        System.out.println("area of triangle "+area);


    }
}