
import java.util.Scanner;

// Java program to find factorial of given number
class Test {
    // method to find factorial of given number
    static int factorial(int n)
    {
        if (n == 0)
            return 1;

        return n * factorial(n - 1);
    }

    // Driver method*/
    public static void main(String[] args)
    {
        int num;
        System.out.println("Enter your factorial number : ");
        Scanner scanner = new Scanner(System.in);
        num = scanner.nextInt();

        System.out.println("Factorial of " + num + " is " + factorial(num));
    }
}
