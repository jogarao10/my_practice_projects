import java.util.Scanner;

public class Main {
    public static void main(String[] args) {

        System.out.print("Enter your temperature in celcius formate : ");
        Scanner scanner = new Scanner(System.in);
        double celcius = scanner.nextDouble();

        double fahrenheit = (celcius * 9/5) + 32;
        System.out.println("your temperature in fahrenheit : "+fahrenheit);
        
    }
}