class Apple
{
  int a=10;
  static int b=20;
  public static void main(String[] args)
 {
   Apple t=new Apple();
   System.out.println(t.a);
   System.out.println(b);
  }
}