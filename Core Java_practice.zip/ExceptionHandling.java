import java.util.*;

class A
{
	void m1()
	{
	String i = null;
	System.out.println("i" +i);
	}
	
}

class ExceptionHandling
{
	public static void main(String[] args)
	{
		A a = new A();
		a.m1();
		
	}
}
		