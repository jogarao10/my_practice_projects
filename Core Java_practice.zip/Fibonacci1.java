import java.util.Scanner;
class Fibo
{
	static void showfibonacci(int no)
	{
		int f1,f2=0,f3=1;
		for(int i=0;i<=no;i++)
		{
			System.out.println(f3);
			f1=f2;
			f2=f3;
			f3=f1+f2;
		}
	}
		public static void main(String args[])
		{
			Scanner sc = new Scanner(System.in);
			System.out.print("enter number");
			int n = sc.nextInt();
			if(0<n)
			{
				showfibonacci(n);
			}
			else
			{
				System.out.print("enter positive number");
			}
		}
}
	
			