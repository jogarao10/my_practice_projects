class BiggestNumber
{
	public static void main(String[] args) 
	{
		int number1 = 10;
        int number2 = 10;
        int number3 = 58;
        
		if(number1 > number2 && number1 > number3)
			{
	        	System.out.println("number1 is biggest:" +number1);
			}
		else if(number2 > number1 && number2 > number3)
		{
				System.out.println("number2 is biggest:" +number2 );
		}
		else if(number3 > number1 && number3 > number2)
		{
			System.out.println("number 3 is biggest:" +number3);
		}
		else
		{
			System.out.println("All numbers are equal");
		}

	}
}
