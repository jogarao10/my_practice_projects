import java.text.DateFormat;
import java.text.NumberFormat;
import java.util.Date;
import java.util.Locale;

public class Hacker {
	public static void main(String[] args)throws Exception {
		Locale locale = new Locale("ar", "SA", "win");
		DateFormat dateFormat = DateFormat.getDateInstance(1, locale);
		Date date = new Date();
		System.out.println(dateFormat.format(date));
	}
}

