class Parent
{	
    public static void main(String[] args) 
	{
		System.out.println("Parent main");
	}
}
class Child extends Parent
{
}






