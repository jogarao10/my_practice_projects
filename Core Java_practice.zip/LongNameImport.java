import static java.lang.Math.sqrt;
import static java.lang.Math.*;
class LongNameImport
{
	public static void main(String[] args)
	{
		
	}
}
