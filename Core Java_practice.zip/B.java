package pack2;
import pack1.A;
class B
{
	public static void main(String[] args)
	{
		A ps = new A();
		ps.m1();
	}
}