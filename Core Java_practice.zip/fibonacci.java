import java.util.Scanner;
public class Fibonacci
{
	static void showfibonacci(int no)
	{
		int f1,f2=1,f3=0;
		for(int i=0;i<=no;i++)
		{
			System.out.println(f3);
			f1=f2;
			f2=f3;
			f3=f1+f2;
		}
	}
	public static void main(String args[])
	{
		Scanner sc = new Scanner(System.in);
		System.out.println("enter number");
		int n=sc.nextInt();
		if(n>0)
		{
			showfibonacci(n);
		}
		else
		{
		System.out.println("enter positive number");
		}
	}
}
		
			