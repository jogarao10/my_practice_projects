/*class Case
{
	public void m1(int i)
	{
	    System.out.println("int-arg");  
	}
	public void m1(char c)
	{
		System.out.println("char");
	}
	public void m1(float f)
	{
		System.out.println("float-arg");
	}
	
	public static void main(String[] arg)
	{
		Case c = new Case();
		c.m1(10);
		c.m1('c');
		c.m1(10.5f);
	}
}*/

import java.util.Scanner;
class Balance
{
	public void m2(int i)
	{
        Scanner s = new Scanner(System.in);
		System.out.print("enter height : ");
        int h = s.nextInt();
		System.out.print("enter berath : ");
        int b = s.nextInt();
		double tr = 0.5 * h * b;
        System.out.print("Area of Triangle is : " + tr);
		
	}
}
class Overloadingcases extends Balance
{
	public void m1(int i)
	{
	    Scanner sc = new Scanner(System.in);
		System.out.print("enter number : ");
		int n = sc.nextInt(); 
		if(n%2==0)
		{
     		System.out.print(n + "is not a prime number");
	    }	 
        System.out.print(n + " is a prime number");	
		
	}
	public void m1(char c)
	{
		System.out.println("char");
	}
	public void m1(float f)
	{
		System.out.println("float-arg");
	}
	
	public static void main(String[] arg)
	{
		Overloadingcases ol = new Overloadingcases();
		ol.m1(10);
		ol.m1('c');
		ol.m1(10.5f);
		ol.m2(10);
	}
}

