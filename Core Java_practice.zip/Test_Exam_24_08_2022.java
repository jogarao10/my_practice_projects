class Test_Exam_24_08_2022 
{
	public static void main(String[] args) 
	{
		//double d = 33.33;
		//int b = (byte)d;
		//System.out.println(b);

		/*char c= 'A';
		int i = c;
		System.out.println(c+"    "+i);
		
		short s = 65;
		char c = (byte)s;
		System.out.println(s+"     "+c);
		
		output = error: incompatible types: possible lossy conversion from byte to char
                char c = (byte)s;


        char c = 'A';
		short s = (byte)c;
		System.out.println(c+"     "+s);

		byte b1 = 30;
		byte b2 = 30;
		byte b = b1+b2;
		System.out.println(b);
		 error: incompatible types: possible lossy conversion from int to byte
                byte b = b1+b2;

        int i = 10;
		long l1 = 20;
		//float f = 22.22f;
		byte l = (byte)i + (byte)l1;
        System.out.println(l);
		error: incompatible types: possible lossy conversion from int to byte
                byte l = (byte)i + (byte)l1;


	    double d = 1234.3456;
		byte b = (short)(int)(long)(float)d;
        System.out.println(b);
		error: incompatible types: possible lossy conversion from short to byte
                byte b = (short)(int)(long)(float)d;


        double d = 1234.3456;
		byte b = (byte)(short)(int)(long)(float)d;
        System.out.println(b);


		int i = 150;
		byte b = (byte)i;
		System.out.println(b);


        int i = 10;
		int j;
		if(i==10)
		{
			j = 20;
		}
		else if(i==10)
		{
			j = 30;
		}
		else
		{
			j = 40;
		}
		System.out.println(j);


		for(int i = 0;i<10 ;i++ )
		{
			System.out.println("Hello");

		}
		System.out.println(i);

		error: cannot find symbol
                System.out.println(i);
                                   ^
         symbol:   variable i
         location: class Test_Exam_24_08_2022



		int i = 10;
		if(i==10)
		{
			int j = 20;
			i = i+j;
		}
		System.out.println(j);

		 error: cannot find symbol
                System.out.println(j);
                                   ^
         symbol:   variable j
         location: class Test_Exam_24_08_2022


        int i = 0; 
        for(;i<10; )
		{
			System.out.println(i);
			i++;

		}
		System.out.println(i);

	
		
		int i = 0;
		for(; ;i++)
		{ 
		}
			System.out.println(i);

			error: unreachable statement
                        System.out.println(i);
					
		
        System.out.println("Before Loop");
        for(int i = 10;i <= 10 || i >= 10;i++)
		{
			 System.out.println("inside Loop");
		}
		System.out.println("After Loop");



		final int i = 10;
		for(final int j = 10;i!=j;)
		{
			System.out.println(i+j);
		}

		error: unreachable statement
                {
                ^      

                                                                       

		int i,j,k,l;
		i = j = k = l = 20;
		System.out.println(i + j);
		*/

		int a = 10;
		int b = 20;
		while (true)
		{
			System.out.println("Hello");
		}
		for (int i =0;i<10;i++)
		{
			System.out.println(i);
		}
		System.out.println("hi");


		


	}
}













