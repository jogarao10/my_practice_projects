class ShortCircuit
{
	public static void main(String[] args)
	{
        int a=17;
		int b=17;
		if((a++ == 12) || (b++ == 12))
		{
			//System.out.println(a+"    "+b);
		}
		System.out.println(a+"    "+b);
	}
}