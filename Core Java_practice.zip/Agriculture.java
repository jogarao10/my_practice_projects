package com.HS.business.Account;
public class Agriculture
{
	public static void main(String[] args)
	{
		System.out.println("India first Agriculture own E-commerce website to dirctly connecting together framers and customers");
	}
}

