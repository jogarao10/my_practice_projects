class Exception
{
	public static void main(String[] args)
	{
		int i = null;
		System.out.println("i.tostring());
	}
}
		