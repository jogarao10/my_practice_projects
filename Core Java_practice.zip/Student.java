class Student
{
	String name;
	int rollno;
	int marks = 92;
	static String collegename;
	public int getStudentInfo()
	{
		return marks = 92;
	}	
	public static void main(String[] args) 
	{
		int getStudentInfo;		
	}
}

		
