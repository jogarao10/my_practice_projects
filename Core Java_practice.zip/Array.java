class Array
{
	public static void main(String[] args)
	{
		sum(new int[] {10,20,30});		
	}
	public static void sum(int[] a)
	{
		int total = 0;
		for(int a1:a)
		{
			total =total+a1;
		}
		System.out.println("The sum:"+total);
	}			
}



