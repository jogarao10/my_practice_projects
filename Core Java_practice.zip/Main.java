class Main
{
	public static void main(int[] args)
	{
		System.out.println("int[]");
	}
	public static void main(byte[] args)
	{
		System.out.println("int[]");
	}
	public static void main(String[] args) 
	{
		System.out.println("String[]");
	}
}
