class Test1
{
  static int x =10;
  public static void main(String[] args)
 {
   Test t = new Test();
   System.out.println(x);
  }
}