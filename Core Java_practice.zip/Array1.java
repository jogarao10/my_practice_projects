class Array1
{
	public static void main(String[] args)
	{
		/*int[] a = new int[10];
		a[0] = 10;
		a[1] = 20;
		byte b = 30;
		a[2] = b;
		char c = 'g';
		a[7] = c;
		System.out.println(a[0]);
		System.out.println(a[2]);
		System.out.println(a[7]);*/
		
		int[] b = {10,20,30,40};
		int[] c = {50,60,70};
		b = c;
		c = b;
		System.out.println(b[1]);
		}
}
