class Test2
{
 public static void main(String[] args)
 {
  int x=10;
  x++;
  System.out.println('a'+'b');
  System.out.println('a'+0.72);
  }
 }