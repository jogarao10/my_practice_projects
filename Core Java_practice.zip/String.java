class Problem
{
	Public Static void main(String[] args)
	{
		int i = 785694231;
		String val = Integer.toString(1);
		String val1 = " "+i;
	}
}