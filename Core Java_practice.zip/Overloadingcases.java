import java.util.Scanner;
class Balance
{
	public void m2(int i)
	{
        Scanner s = new Scanner(System.in);
		System.out.print("enter height : ");
        int h = s.nextInt();
		System.out.print("enter berath : ");
        int b = s.nextInt();
		double tr = 0.5 * h * b;
        System.out.println("Area of Triangle is : " + tr);
		
	}
}
class Overloadingcases extends Balance
{
	public void m1(int i)
	{
	    Scanner sc = new Scanner(System.in);
		System.out.print("enter number : ");
		int n = sc.nextInt(); 
		if(n%2==0)
		{
     		System.out.println(n + "is not a prime number");
	    }	 
        System.out.println(n + " is a prime number");	
		
	}
	public void m1(char c)
	{
		System.out.println("char");
	}
	public void m1(float f)
	{
		System.out.println("float");
	}
	public void m3(int i)
	{
		System.out.println("int");
	}
	
	public static void main(String[] arg)
	{
		Overloadingcases ol = new Overloadingcases();
		ol.m1(10);
		ol.m1('c');
		ol.m1(78.0f);
		ol.m2(79);
		ol.m3(10);
	}
}
