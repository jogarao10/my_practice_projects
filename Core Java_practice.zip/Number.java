class Number
{
}