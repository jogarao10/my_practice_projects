class FirstApp{
    public static void main(String[] args){
        System.out.println("Welcome To Brackets Text Editor");
    }
}