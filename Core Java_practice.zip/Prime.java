import java.util.Scanner;
class Prime
{
	/*static void showfibonacci(int no)
	{
		
		
	}*/
		public static void main(String args[])
		{
			Scanner sc = new Scanner(System.in);
			System.out.print("enter number");
			int n = sc.nextInt();
			for(int i=1;i<=n;i++)
			{
			if(n%i==0)
			{
				
				System.out.print(i);
			}
			}
		}
		
}
