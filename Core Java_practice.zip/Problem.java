class Problem1
{
	public static void main(String[] args)
	{
		//int i = 785694231;
		//String val = Integer.toString(i);
		//System.out.println(val);
		
		System.out.println("Hello");
	}
}