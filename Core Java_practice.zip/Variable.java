class Variable
{
	public static void main(String[] args)
	{
		m1(10,20);
		Variable v = new Variable();
		v.m2();
	}
	public static void m1(int x,int y)
	{
		x=101;
		y=201;
		System.out.println(x+"----"+y);
	}	
	int x = 10;
	
	public void m2()
	{
		System.out.println(x);
	}
	
}