class ArrayEachForLoop
{
 public static void main(String[] args)
 {
 /*two dimensional normal Array
 int[][] x={{10,20},{30,40}};
  for(int i=0;i<x.length;i++)
  {
    for(int j=0;j<x[i].length;j++)
    {
      System.out.println(x[i][j]);
    }
  }*/
  //two dimensional for-each loop
  /*
  int[][] x={{10,20,30},{40,50}};
  for(int[] x1:x)
 {
   for(int x2:x1)
  {
    System.out.println(x2);
   }
  }*/



 
  /*int[][][] x={{{10,20},{30,40}},{{50,60,70},{80,90}}};
  for(int i=0;i<x.length;i++)
  {
    for(int j=0;j<x[i].length;j++)
    {
      for(int k=0;k<x[i][j].length;k++)
      {
      System.out.println(x[i][j][k]);
      }
    }
   }*/
 }
}
  