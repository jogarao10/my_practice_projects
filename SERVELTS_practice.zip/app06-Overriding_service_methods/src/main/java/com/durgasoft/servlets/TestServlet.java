package com.durgasoft.servlets;

import jakarta.servlet.ServletException;

import jakarta.servlet.ServletRequest;
import jakarta.servlet.ServletResponse;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;


public class TestServlet extends HttpServlet{
	private static final long serialVersionUID = 1L;
	static {
		System.out.println("Test Servlet Loading");
	}
	public TestServlet() {
		System.out.println("Test Servlet Instantiation");
	}
	@Override
	public void init() throws ServletException {
		System.out.println("Test servlet Initialization");
	}

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		System.out.println("TestServlet Resquest processing");
	}
	public void destroy() {
		System.out.println("TestServlet Servlet Deinstantiation");
	}

}
