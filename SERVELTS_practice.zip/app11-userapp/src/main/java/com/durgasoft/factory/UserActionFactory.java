package com.durgasoft.factory;

import com.durgasoft.action.UserAction;

public class UserActionFactory {
	private static UserAction userAction;
	static {
		userAction = new UserAction();
	}
	public static UserAction getUserAction() {
		return userAction;
	}
	
	
}
