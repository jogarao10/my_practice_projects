package com.durgasoft.action;


import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;

import com.durgasoft.factory.ConnectionFactory;

public class UserAction {
	public String checkLogin(String uname,String upwd) {
		String status = "";
		try {
			Connection connection = ConnectionFactory.getConnection();
			Statement statement = connection.createStatement();
			ResultSet resultSet = statement.executeQuery("select * from reg_users where UNAME = '"+uname+"' and UPWD ='"+upwd+"'");
			boolean b = resultSet.next();
			if(b == true) {
				status = "success";
			}else {
				status = "failure";
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		return status;
	}
	public String registration(String uname, String upwd, String uemail, String umobile) {
		String status = "";
		try {
			Connection connection = ConnectionFactory.getConnection();
			Statement statement = connection.createStatement();
			ResultSet resultSet = statement.executeQuery("select * from reg_Users where UNAME = '"+uname+"'");
			boolean b = resultSet.next();
			if(b == true) {
				status = "User Existed";
			}else {
				int rowCount = statement.executeUpdate("insert into reg_users values('"+uname+"','"+upwd+"','"+uemail+"','"+umobile+"')");
				if(rowCount == 1) {
					status = "success";
				}else {
					status = "failure";
				}
			}
			
		} catch (Exception e) {
			status = "failure";
			e.printStackTrace();
		}
		
		return status;
	}
}
