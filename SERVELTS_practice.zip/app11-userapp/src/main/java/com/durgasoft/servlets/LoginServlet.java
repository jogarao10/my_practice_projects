package com.durgasoft.servlets;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;

import com.durgasoft.action.UserAction;
import com.durgasoft.factory.UserActionFactory;
@WebServlet("/login")
public class LoginServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		response.setContentType("text/html");
		PrintWriter out = response.getWriter();
		
		String uname = request.getParameter("uname");
		String upwd = request.getParameter("upwd");
		
		UserAction userAction = UserActionFactory.getUserAction();
		String status = userAction.checkLogin(uname, upwd);
		
		out.println("<html>");
		out.println("<body bgcolor='lightblue'>");
		out.println("<br><br><br>");
		out.println("<h1 style='color: red;' align='center'>");
		if(status.equalsIgnoreCase("success")) {
			out.println("user login success");
		}else {
			out.println("user login failuare");
		}
		out.println("</h1></body></html>");
	}

}
