package com.durgasoft.servlets;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;

import com.durgasoft.action.UserAction;
import com.durgasoft.factory.UserActionFactory;

@WebServlet("/reg")
public class RegistrationServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		response.setContentType("text/html");
		PrintWriter out = response.getWriter();
		
		String uname = request.getParameter("uname");
		String upwd = request.getParameter("upwd");
		String uemail = request.getParameter("uemail");
		String umobile = request.getParameter("emobile");
		
		UserAction userAction = UserActionFactory.getUserAction();
		String status = userAction.registration(uname, upwd, uemail, umobile);
		
		out.println("<html>");
		out.println("<body bgcolor='lightblue'>");
		out.println("<br><br><br><br>");
		out.println("<h1 style='color:red;' align='center'>");
		if(status.equalsIgnoreCase("existed")) {
			out.println("user already existed");
		}
		if(status.equalsIgnoreCase("success")) {
			out.println("user Registration success");
		}
		if(status.equalsIgnoreCase("failure")) {
			out.println("user Registration failure");
		}
		out.println("</h1></body></html>");
		
		
		
	}

}
