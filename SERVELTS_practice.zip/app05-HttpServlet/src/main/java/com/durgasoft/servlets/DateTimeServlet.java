package com.durgasoft.servlets;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.util.Date;
public class DateTimeServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html");
		PrintWriter out = response.getWriter();
		
		LocalDateTime localDateTime = LocalDateTime.now();
		
		LocalDate localDate = LocalDate.now();
		String date = localDate.getDayOfMonth()+"-"+localDate.getMonthValue()+"-"+localDate.getYear();
		
		LocalTime localTime = LocalTime.now();
		String time = localTime.getHour()+":"+localTime.getMinute()+":"+localTime.getSecond();
		
		out.println("<html>");
		out.println("<body>");
		out.println("<h1 style='color: red>");
		out.println("Hello user! welcome to our https servlet programming");
		out.println("<br>");
	
		out.println("Date   :  "+date);
		out.println("<br>");
		out.println("Time   :  "+time);
		out.println("</h1>");
		out.println("</body></html>");
		
	}

}
