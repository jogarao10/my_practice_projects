package com.durgasoft.app04.servlets;

import jakarta.servlet.GenericServlet;
import jakarta.servlet.ServletException;
import jakarta.servlet.ServletRequest;
import jakarta.servlet.ServletResponse;
import jakarta.servlet.annotation.WebServlet;
import java.io.IOException;
import java.io.PrintWriter;
import java.time.LocalTime;

public class WishServlet extends GenericServlet {
	private static final long serialVersionUID = 1L;
	public void service(ServletRequest request, ServletResponse response) throws ServletException, IOException {
		
		response.setContentType("text/html");
		PrintWriter out = response.getWriter();
		
		LocalTime time = LocalTime.now();
		int hour = time.getHour();
		String wishMessage = "";
		if(hour < 12) {
			wishMessage = "Good Morning";
		}else if(hour > 12 && hour < 17) {
			wishMessage = "Good Afternoon";
		}else {
			wishMessage = "Good Evening";
		}
		
		out.println("<html>");
		out.println("<body>");
		out.println("<h1 style='color: red;'>");
		out.println("hello Durga, "+wishMessage);
		out.println("</h1></body></html>");
		
	}

}
