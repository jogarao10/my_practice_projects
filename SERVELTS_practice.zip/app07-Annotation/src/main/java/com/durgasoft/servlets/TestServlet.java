package com.durgasoft.servlets;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;

@WebServlet(
		name = "TestPattern",
		urlPatterns = {"/test1","/test2","/test3"},
		loadOnStartup=1
		)

public class TestServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	
	static {
		System.out.println("Servlet loading.......");
	}
	public TestServlet() {
		System.out.println("servlet Instanstation...........");
	}
	@Override
	public void init() throws ServletException {
		System.out.println("servlet Initialization..........");
	}
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		System.out.println("response creating.........");
		response.setContentType("text/html");
		
		PrintWriter out = response.getWriter();
		
		out.println("<html>");
		out.println("<head>");
		out.println("Annatations");
		out.println("</head>");
		out.println("<body>");
		out.println("<h1>");
		out.println("Hello user , This is Annatation servlet");
		
		out.println("</h1></head></html>");
		
		
	
	}
	@Override
	public void destroy() {
		System.out.println("servlet Deinstanstation.........");
	}
}






























