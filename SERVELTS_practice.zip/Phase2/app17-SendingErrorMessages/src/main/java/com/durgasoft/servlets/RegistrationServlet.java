package com.durgasoft.servlets;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

@WebServlet("/reg")
public class RegistrationServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		response.setContentType("text/html");
		PrintWriter out = response.getWriter();
		
		String sname = request.getParameter("sname");
		String squal = request.getParameter("squal");
		String[] scourses = request.getParameterValues("scourse");
		List<String> courses = List.of(scourses);
		
		List<String> qualifications = List.of("BSC","BTECH","MCA","MTECH");
		if (qualifications.contains(squal)) {
			out.println("<html>");
			out.println("<body>");
			out.println("<h1 style='color: red;' align='center'>");
			out.println("Hello "+sname+", Thank you for enquiry , very soon Our team will be content to you");
			out.println("</h1>");
			out.println("<h3 align='center'><a href='./courseregistrationform.html'>|Course Registration form|</a></h3>");
			out.println("</body></html>");
		}else {
			response.sendError(506, "You opted the courses "+courses+", You are not eligble for this course, because your Qualification is "+squal);
			
		}
		
	}

}
