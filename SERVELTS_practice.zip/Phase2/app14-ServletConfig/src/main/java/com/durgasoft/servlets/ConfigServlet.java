package com.durgasoft.servlets;

import jakarta.servlet.ServletConfig;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebInitParam;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.Enumeration;


public class ConfigServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		response.setContentType("text/html");
		PrintWriter out = response.getWriter();
		
		ServletConfig config = getServletConfig();
		
		String name = config.getServletName();
		String driverClass = config.getInitParameter("driverClass");
		String driverURL = config.getInitParameter("driverURL");
		String dbUserName = config.getInitParameter("dbUserName");
		String dbPassword = config.getInitParameter("dbPassword");
		
		Enumeration<String> enumeration = config.getInitParameterNames();
		String initParamNames = "";
		while(enumeration.hasMoreElements()) {
			initParamNames = initParamNames + enumeration.nextElement() + "<br>";
		}
		out.println("<html>");
		out.println("<body>");
		out.println("<h2 style = 'color:red;' align = 'center'>ServletConfig Data</h2>");
		out.println("<table border='1' align = 'center'");
		out.println("<tr><td>Logical Name</td><td>"+name+"</td></tr>");
		out.println("<tr><th>Init Param Name</th><th>Init param Value</th></tr>");
		out.println("<tr><td>Driver Class</td><td>"+driverClass+"</td></tr>");
		out.println("<tr><td>Driver URL</td><td>"+driverURL+"</td></tr>");
		out.println("<tr><td>DataBase User Name</td><td>"+dbUserName+"</td></tr>");
		out.println("<tr><td>DataBase Password</td><td>"+dbPassword+"</td></tr>");
		out.println("<tr><th colspan = '2'>Parameter Names</th></tr>");
		out.println("<tr><td colspan = '2' align='center'>"+initParamNames+"</td></tr>");
		out.println("</table></body></html>");
		
		
		
		
		
		
		
		
		
		
		
		
		
		
	}

}
