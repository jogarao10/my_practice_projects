package com.durgasoft.servlets;

import jakarta.servlet.ServletContext;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.Enumeration;
import java.util.*;

public class ContextServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html");
		PrintWriter out = response.getWriter();
		
		ServletContext context = getServletContext();
		context.setAttribute("A",111);
		context.setAttribute("B",222);
		context.setAttribute("C",333);
		context.setAttribute("D",444);
		
		String logicalName = context.getServletContextName();
		String driverClass = context.getInitParameter("driverClass");
		String driverURL  = context.getInitParameter("driverURL");
		String dbUserName = context.getInitParameter("dbUserName");
		String dbPassword = context.getInitParameter("dbPassword");
		
		Enumeration<String> enumeration1 = context.getInitParameterNames();
		
		Integer a = (Integer) context.getAttribute("A");
		Integer b = (Integer) context.getAttribute("B");
		Integer c = (Integer) context.getAttribute("C");
		Integer d = (Integer) context.getAttribute("D");
		
		Enumeration<String> enumeration2 = context.getAttributeNames();
		
		out.println("<html>");
		out.println("<body>");
		out.println("<h2 style = 'color: red;' align='center'>Servlet Context Details</h2>");
		out.println("<table border='1' align = 'center' >");
		out.println("<tr><th>Logical Name</th><td>"+logicalName+"</td></tr>");
		out.println("<tr><th>Context param Names</th><th>Context param Values</th></tr>");
		out.println("<tr><td>driverclass</td><td>"+driverClass+"</td></tr>");
		out.println("<tr><td>driverURL</td><td>"+driverURL+"</td></tr>");
		out.println("<tr><td>dbUserName</td><td>"+dbUserName+"</td></tr>");
		out.println("<tr><td>dbPassword</td><td>"+dbPassword+"</td></tr>");
		out.println("<tr><td>Context param Names</td><td>");
		while(enumeration1.hasMoreElements()) {
			out.println(enumeration1.nextElement()+"<br>");
		}
		out.println("</td></tr>");
		
		out.println("<tr><th>Context Attribute Names</th><th>Context Attribute values</th></tr>");
		
		out.println("<tr><td>a</td><td>"+a+"</td></tr>");
		out.println("<tr><td>b</td><td>"+b+"</td></tr>");
		out.println("<tr><td>c</td><td>"+c+"</td></tr>");
		out.println("<tr><td>d</td><td>"+d+"</td></tr>");
		out.println("<tr><td>Context Attributes Names</td><td>");
		while(enumeration2.hasMoreElements()) {
			out.println(enumeration2.nextElement()+"<br>");
		}
		out.println("</td></tr>");
		out.println("<tr><td>Foregin Context</td><td>"+context.getContext("app14-ServletConfig")+"</td></tr>");
		out.println("</table></body></html>");
	}

}
