package com.durgasoft;

import org.hibernate.*;
import org.hibernate.boot.registry.StandardServiceRegistryBuilder;
import org.hibernate.cfg.Configuration;

public class Main {
    public static void main(String[] args) {

        Configuration configuration = new Configuration();
        configuration.configure();

        SessionFactory sessionFactory = configuration.buildSessionFactory(new StandardServiceRegistryBuilder().applySettings(configuration.getProperties()).build());
        Session session = sessionFactory.openSession();
        Query query = session.createQuery("insert into Employee2(eno,ename,esal,eaddr)select e.eno, e.ename, e.esal, e.eaddr from Employee1 as e");
        Transaction transaction = session.beginTransaction();
        int rowCount = query.executeUpdate();
        transaction.commit();
        System.out.println("Records Transfored   : "+rowCount);

        session.close();
        sessionFactory.close();


    }
}