package com.durgasoft;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.boot.registry.StandardServiceRegistryBuilder;
import org.hibernate.cfg.Configuration;

import java.util.List;

public class Main {
    public static void main(String[] args) {
        Configuration configuration = new Configuration();
        configuration.configure();

        SessionFactory sessionFactory = configuration.buildSessionFactory(new StandardServiceRegistryBuilder().applySettings(configuration.getProperties()).build());
        Session session = sessionFactory.openSession();

        /*Query query = session.createQuery("fROM Employee As e");
        List<Employee> list = query.list();
        System.out.println("ENO\tENAME\tESAL\tEADDR");
        System.out.println("--------------------------------------");
        for (Employee emp:list) {
                System.out.print(emp.getEno()+"\t");
                System.out.print(emp.getEname()+"\t\t");
                System.out.print(emp.getEsal()+"\t");
                System.out.print(emp.getEaddr()+"\n");
        }*/
        /* Query query = session.createQuery("select e.eno, e.ename, e.esal, e.eaddr FROM Employee As e");
        List<Object[]> list = query.list();
        System.out.println("ENO\tENAME\tESAL\tEADDR");
        System.out.println("-------------------------------");
        for (Object[] objects : list){
            for (Object obj:objects){
                System.out.print(obj+"\t");
            }
            System.out.println();
        }*/
        /*
        Query query = session.createQuery("select e.eno, e.ename, e.esal, e.eaddr FROM Employee As e where esal <7000");
        List<Object[]> list = query.list();
        System.out.println("ENO\tENAME\tESAL\tEADDR");
        System.out.println("------------------------------");
        for (Object[] objects:list){
            for (Object obj: objects){
                System.out.print(obj+"\t");
            }
            System.out.println();
        }
        * */
        /*Query query = session.createQuery("select e.eno, e.ename, e.esal, e.eaddr FROM Employee As e where esal <7000 order by esal desc");
        List<Object[]> list = query.list();
        System.out.println("ENO\tENAME\tESAL\tEADDR");
        System.out.println("------------------------------");
        for (Object[] objects:list){
            for (Object obj: objects){
                System.out.print(obj+"\t");
            }
            System.out.println();
        }

         */
        /*Query query = session.createQuery("select sum(e.esal) from Employee As e group by e.ename");
        List<Double> list = query.list();
        System.out.println("Total Salary");
        System.out.println("-----------------");
        for (Double d : list){
            System.out.println(d);
        }

         */
        /*
         Query query = session.createQuery("select sum(e.esal) from Employee As e group by e.ename having e.ename = 'AAA'");
//        Query query = session.createQuery("select sum(e.esal) FROM Employee AS e group by e.esal having e.esal <= 7000");

        List<Double> list = query.list();
        for (Double d : list){
            System.out.println(d);
        }

        * */
        Query query = session.createQuery("select count(e.eaddr) from Employee As e group by e.eaddr");
        List<Long> list = query.list();
        for (Long l: list){
            System.out.println(l);
        }

        session.close();
        sessionFactory.close();




    }
}