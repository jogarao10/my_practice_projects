package com.durgasoft;

import com.durgasoft.entities.Employee;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

import java.io.FileInputStream;
import java.util.Properties;

public class Main {
    public static void main(String[] args) throws Exception{
        Configuration configuration = new Configuration();
//        configuration.addResource("Employee.hbm.xml");
        FileInputStream fileInputStream = new FileInputStream("H:\\Practice\\HIBERNATE\\INTELLIJ\\app11_DeclarativeApproach_UsingPropertiesFiles\\src\\main\\resources\\abc.properties");
        Properties properties = new Properties();
        properties.load(fileInputStream);
        configuration.setProperties(properties);

        configuration.addAnnotatedClass(Employee.class);
        configuration.addAnnotatedClass(Employee.class);
        SessionFactory sessionFactory = configuration.buildSessionFactory();
        Session session = sessionFactory.openSession();

        Employee employee = (Employee) session.get(Employee.class, 111);

        if (employee==null){
            System.out.println("Employee does not exit");
        }else {
            System.out.println("Employee Deatils ");
            System.out.println("------------------------------");
            System.out.println("Employee Number  :  "+employee.getEno());
            System.out.println("Employee Name    :  "+employee.getEname());
            System.out.println("Employee Salary  :  "+employee.getEsal());
            System.out.println("Employee Address :  "+employee.getEaddr());
        }


    }
}