package com.durgasoft;

import com.durgasoft.entities.Employee;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

public class Main {
    public static void main(String[] args) throws Exception{
        Configuration configuration = new Configuration();
        configuration.setProperty("hibernate.connection.driver_Class","com.mysql.cj.jdbc.Driver");
        configuration.setProperty("Hibernate.connection.url","jdbc:mysql://localhost:3306/chantidb");
        configuration.setProperty("Hibernate.connection.username","root");
        configuration.setProperty("Hibernate.connection.password","chanti");
        configuration.setProperty("hibernate.dialect","org.hibernate.dialect.MySQLDialect");
        configuration.addResource("Employee.hbm.xml");
        SessionFactory sessionFactory = configuration.buildSessionFactory();
        Session session = sessionFactory.openSession();
        Employee employee = (Employee) session.get(Employee.class,222);
        if (employee == null){
            System.out.println("Employee Does not exit");
        }else {
            System.out.println("Employee Details");
            System.out.println("----------------------------------");
            System.out.println("employee Number     :  " + employee.getEno());
            System.out.println("employee Name       :  " + employee.getEname());
            System.out.println("employee Salary     :  " + employee.getEsal());
            System.out.println("employee Address    :  " + employee.getEaddr());
        }
        session.close();
        sessionFactory.close();


    }
}