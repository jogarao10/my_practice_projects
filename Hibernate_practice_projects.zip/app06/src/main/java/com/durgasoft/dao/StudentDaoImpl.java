package com.durgasoft.dao;

import com.durgasoft.beans.Student;
import com.durgasoft.factories.HibernateUtil;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;

public class StudentDaoImpl implements StudentDao{
    @Override
    public String add(Student student) {
        String status = "";
        Transaction transaction = null;
        try {
            SessionFactory sessionFactory = HibernateUtil.getSessionFactory();
            Session session = sessionFactory.openSession();
            transaction = session.beginTransaction();
            String pkVal = (String) session.save(student);


            if(pkVal.equals(student.getSid())){
                transaction.commit();
                status = "SUCCESS";
            }else{
                transaction.rollback();
                status = "FAILURE";
            }
        }catch (Exception exception){
            transaction.rollback();
            status = "FAILURE";
            exception.printStackTrace();
        }
        return status;

    }


    @Override
    public Student search(String sid) {
        return null;
    }

    @Override
    public String update(Student student) {
        return null;
    }

    @Override
    public String delete(Student student) {
        return null;
    }
}
