package com.durgasoft;

import com.durgasoft.beans.Student;
import com.durgasoft.factories.StudentServiceFactory;
import com.durgasoft.service.StudentService;
import com.durgasoft.factories.HibernateUtil;

import java.io.BufferedReader;
import java.io.InputStreamReader;

public class Main {
    public static void main(String[] args) throws Exception{

        System.out.println("Student Management System Application");
        System.out.println("=============================================");
        try {
            BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(System.in));
            String sid="", sname="",saddr="";
            Student student = null;
            String status = "";
            StudentService studentService = StudentServiceFactory.getStudentService();

            while (true){
                System.out.println("1.  ADD STUDENT");
                System.out.println("2.  SEARCH STUDENT");
                System.out.println("3.  UPDATE STUDENT");
                System.out.println("4.  DELETE STUDENT");
                System.out.println("5.  EXIT");
                System.out.println("YOUR OPTION     : ");
                int userOption = Integer.parseInt(bufferedReader.readLine());


                switch (userOption){
                    case 1:
                        System.out.println("ADD Student Module");
                        System.out.println("--------------------------");
                        System.out.print("Enter Student Id        :  ");
                        sid = bufferedReader.readLine();
                        System.out.print("Enter Student Name      :  ");
                        sname = bufferedReader.readLine();
                        System.out.print("Enter Student Address   : ");
                        saddr = bufferedReader.readLine();

                        student = new Student();
                        student.setSid(sid);
                        student.setSname(sname);
                        student.setSaddr(saddr);

                        status = studentService.addStudent(student);
                        System.out.println("ststus     :  "+status);


                        break;
                    case 2:
                        break;
                    case 3:
                        break;
                    case 4:
                        break;
                    case 5:
                        System.out.println("Thank you for using student management system, visit again");
                        System.exit(0);
                        break;
                    default:
                        System.out.println("Your entry is wrong, please provide the options from 1,2,3,4, and 5");
                }

            }

        }catch (Exception exception){
            exception.printStackTrace();
        }
    }
}