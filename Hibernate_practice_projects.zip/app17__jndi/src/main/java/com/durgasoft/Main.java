package com.durgasoft;

import com.durgasoft.beans.Employee;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.boot.registry.StandardServiceRegistryBuilder;
import org.hibernate.cfg.Configuration;

import java.util.Scanner;

public class Main {
    public static void main(String[] args) {

        Configuration configuration = new Configuration();
        configuration.configure();

        SessionFactory sessionFactory = configuration.buildSessionFactory(new StandardServiceRegistryBuilder().applySettings(configuration.getProperties()).build());
        Session session = sessionFactory.openSession();

        Scanner sc = new Scanner(System.in);
        System.out.print("Enter Employee Number   :  ");
        int eno = sc.nextInt();
        Employee employee = (Employee) session.get(Employee.class,eno);

        if (employee == null){
            System.out.println("Employee does not exit");
        }else{
            System.out.println("Employee Details");
            System.out.println("---------------------------");
            System.out.println("Employee Number    :  "+employee.getEno());
            System.out.println("Employee Name      :  "+employee.getEname());
            System.out.println("Employee Salary    :  "+employee.getEsal());
            System.out.println("Employee Address   :  "+employee.getEaddr());
        }
    }
}