package com.durgasoft;

import com.durgasoft.entities.Employee;
import org.hibernate.Query;
import org.hibernate.ScrollableResults;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.boot.registry.StandardServiceRegistryBuilder;
import org.hibernate.cfg.Configuration;

import java.util.Iterator;
import java.util.List;

public class Main {
    public static void main(String[] args) {
        Configuration configuration = new Configuration();
        configuration.configure();

        SessionFactory sessionFactory = configuration.buildSessionFactory(new StandardServiceRegistryBuilder().applySettings(configuration.getProperties()).build());

        Session session = sessionFactory.openSession();

        Query query = session.createQuery("from Employee");
        List <Employee> list = query.list();


        System.out.println("Dispaly Details by using List() method");
        System.out.println("ENO\tENAME\tESAL\tEADDR");
        System.out.println("****************************************");
        for (Employee emp : list){
            System.out.print(emp.getEno()+"\t");
            System.out.print(emp.getEname()+"\t");
            System.out.print(emp.getEsal()+"\t");
            System.out.print(emp.getEaddr()+"\n");
        }

        System.out.println("");

        Iterator<Employee> iterator = query.iterate();
        System.out.println("Display Details by Using Iterator() method");
        System.out.println("ENO\tENAME\tESAL\tEADDR");
        System.out.println("###################################################");
        while (iterator.hasNext()){
            Employee emp = iterator.next();

            System.out.print(emp.getEno()+"\t");
            System.out.print(emp.getEname()+"\t");
            System.out.print(emp.getEsal()+"\t");
            System.out.print(emp.getEaddr()+"\n");
        }
        System.out.println();

        ScrollableResults scrollableResults = query.scroll();
        System.out.println("Display Details by Using foward direction method");
        System.out.println("ENO\tENAME\tESAL\tEADDR");
        System.out.println("$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$");
        while (scrollableResults.next()){
            Object[] obj = scrollableResults.get();
            for (Object o : obj){
                Employee employee = (Employee) o;
                System.out.print(employee.getEno()+"\t");
                System.out.print(employee.getEname()+"\t");
                System.out.print(employee.getEsal()+"\t");
                System.out.print(employee.getEaddr()+"\n");
            }
        }
        System.out.println("");
        System.out.println("Display Details by Using ,backword direction method");
        System.out.println("ENO\tENAME\tESAL\tEADDR");
        System.out.println("%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%");
        while (scrollableResults.previous()){
            Object[] obj = scrollableResults.get();
            for (Object o: obj){
                Employee employee = (Employee) o;
                System.out.print(employee.getEno()+"\t");
                System.out.print(employee.getEname()+"\t");
                System.out.print(employee.getEsal()+"\t");
                System.out.print(employee.getEaddr()+"\n");
            }
        }
        System.out.println();
        System.out.println();


        System.out.println("Using uniqueResult()");
        Query query1 = session.createQuery("from Employee where eno=111");
        Object obj = query1.uniqueResult();
        Employee emp = (Employee) obj;
        System.out.println("Employee Details");
        System.out.println("-----------------------");
        System.out.println("Employee Number : "+emp.getEno());
        System.out.println("Employee Name : "+emp.getEname());
        System.out.println("Employee Salary : "+emp.getEsal());
        System.out.println("Employee Address : "+emp.getEaddr());




        sessionFactory.close();
        session.close();


        }
}