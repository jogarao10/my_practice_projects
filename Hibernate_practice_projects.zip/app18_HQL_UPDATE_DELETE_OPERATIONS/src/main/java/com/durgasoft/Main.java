package com.durgasoft;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.boot.registry.StandardServiceRegistryBuilder;
import org.hibernate.cfg.Configuration;

import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Configuration configuration = new Configuration();
        configuration.configure();

        SessionFactory sessionFactory = configuration.buildSessionFactory(new StandardServiceRegistryBuilder().applySettings(configuration.getProperties()).build());
        Session session = sessionFactory.openSession();

        /*
        * Scanner scanner = new Scanner(System.in);
        System.out.println("Enter how much amount added  : ");
        float amountadd = scanner.nextFloat();

        Query query = session.createQuery("update Employee set esal = esal + :esal where esal < 10000");
        query.setParameter("esal",amountadd);
        Transaction transaction = session.beginTransaction();

        int rowCount = query.executeUpdate();
        transaction.commit();
        System.out.println("Employee table is updated  : "+rowCount);
         */


        Scanner scanner = new Scanner(System.in);
        System.out.println("Enter location  : ");
        String location = scanner.nextLine();

        Query query = session.createQuery("delete from Employee where eaddr LIKE :location ");

        query.setParameter("location","%" +location+"%");
        Transaction transaction = session.beginTransaction();

        int rowCount = query.executeUpdate();
        transaction.commit();
        System.out.println("Employee table is deleted  : "+rowCount);

        session.close();
        sessionFactory.close();
    }
}