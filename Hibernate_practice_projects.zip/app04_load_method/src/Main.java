import com.durgasoft.app04.entities.Employee;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

import java.util.Scanner;

public class Main {
    public static void main(String[] args) throws Exception{
        Configuration configuration = new Configuration();
        configuration.configure();

        SessionFactory sessionFactory = configuration.buildSessionFactory();
        Session session = sessionFactory.openSession();

        /*
        * /System.out.print("Enter Employee Id Number   :  ");
        Scanner sc = new Scanner(System.in);
        int eno = sc.nextInt();
        */

        Employee employee = (Employee) session.load(Employee.class, 222);
        if (employee == null){
            System.out.println("Employee does not exit");
        }else{
            System.out.println("Employee Details");
            System.out.println("-------------------------");
            System.out.println("Employee Number    :  "+employee.getEno());
            System.out.println("Employee Name      :  "+employee.getEname());
            System.out.println("Employee Salary    :  "+employee.getEsal());
            System.out.println("Employee Address   :  "+employee.getEaddr());

        }
        session.close();
        sessionFactory.close();


    }
}