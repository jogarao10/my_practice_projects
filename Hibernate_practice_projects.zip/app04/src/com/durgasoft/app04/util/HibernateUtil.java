package com.durgasoft.app04.util;

public class HibernateUtil {

}
